# 5.Apagar Registos 
# Crie um programa que permita apagar registos da tabela clientes com base no Id,
# garantindo:
# Validação da existência do Id antes da remoção;
# Possibilidade de novas tentativas caso o Id não exista.


import mysql.connector

def apagar_registos(nome_base_dados, host="localhost", user="root", password=""):
    """
    Permite apagar registos da tabela 'clientes' com base no Id, com validação e opção de retentar.

    Args:
        nome_base_dados (str): O nome da base de dados.
        host (str): O endereço do servidor MySQL (padrão: "localhost").
        user (str): O nome de usuário do MySQL (padrão: "root").
        password (str): A senha do MySQL.
    """
    conexao = None  # Inicializa a variável de conexão fora do bloco try
    try:
        conexao = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=nome_base_dados
        )
        cursor = conexao.cursor()

        while True:  # Loop para permitir novas tentativas
            id_cliente_str = input("Insira o ID do cliente que pretende apagar (ou 'sair' para cancelar): ").strip()

            if id_cliente_str.lower() == 'sair':
                print("Operação de apagar registo cancelada pelo utilizador.")
                break  # Sai do loop se o utilizador digitar 'sair'

            if not id_cliente_str.isdigit():
                print("❌ Erro: ID de cliente inválido. Por favor, insira um número inteiro ou 'sair'.")
                continue  # Volta ao início do loop para pedir um ID válido

            id_cliente = int(id_cliente_str)

            # Verifica se o ID existe antes de tentar apagar
            cursor.execute("SELECT 1 FROM clientes WHERE Id = %s", (id_cliente,))
            cliente_existe = cursor.fetchone()

            if cliente_existe:
                # Confirmação antes de apagar
                confirmacao = input(f"Tem certeza que pretende apagar o cliente com ID {id_cliente}? (sim/não): ").strip().lower()
                if confirmacao == 'sim':
                    # Executa o DELETE se o ID existir e a confirmação for 'sim'
                    cursor.execute("DELETE FROM clientes WHERE Id = %s", (id_cliente,))
                    conexao.commit()
                    print(f"✅ Cliente com ID {id_cliente} apagado com sucesso!")
                    break  # Sai do loop após apagar com sucesso
                else:
                    print(f"Operação de apagar cliente com ID {id_cliente} cancelada.")
            else:
                print(f"❌ Erro: Não existe cliente com o ID {id_cliente} na base de dados.")
                tentar_novamente = input("Deseja tentar novamente com outro ID? (sim/não): ").strip().lower()
                if tentar_novamente != 'sim':
                    print("Operação de apagar registo terminada.")
                    break  # Sai do loop se o utilizador não quiser tentar novamente
                # Se o utilizador digitar 'sim', o loop continua para pedir outro ID

    except mysql.connector.Error as erro:
        print(f"❌ Erro ao apagar registo: {erro}")
        if conexao:
            conexao.rollback()  # Faz rollback em caso de erro

    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close()
            print("🔒 Conexão ao MySQL fechada.")

# Exemplo de uso da função para apagar registos da tabela 'clientes'
nome_base_dados = "MinhaLojaBonita"
apagar_registos(nome_base_dados)