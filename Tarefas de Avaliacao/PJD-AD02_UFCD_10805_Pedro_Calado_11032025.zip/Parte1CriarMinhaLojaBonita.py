# Parte 1: Operações Básicas com MySQL
# 1. Criar Base de Dados Crie um programa Python 
# que crie uma base de dados MySQL com o nome MinhaLojaBonita.

import mysql.connector

def criar_base_dados(nome_base_dados):
    """
    Cria uma base de dados MySQL com o nome especificado.

    Args:
        nome_base_dados (str): O nome da base de dados a ser criada.
    """
    try:
        # Configurações de conexão
        conexao = mysql.connector.connect(
            host="localhost",
            user="root",
            password=""
        )
        cursor = conexao.cursor()

        # Obtém a lista de bases de dados existentes
        cursor.execute("SHOW DATABASES")
        bases_existentes = [db[0] for db in cursor.fetchall()]

        if nome_base_dados in bases_existentes:
            print(f"A base de dados '{nome_base_dados}' já existe.")
        else:
            # Cria a base de dados
            cursor.execute(f"CREATE DATABASE `{nome_base_dados}`")
            print(f"Base de dados '{nome_base_dados}' criada com sucesso!")

    except mysql.connector.Error as erro:
        print(f"Erro ao criar a base de dados: {erro}")

    finally:
        if 'conexao' in locals() and conexao.is_connected():
            cursor.close()
            conexao.close()


# Chamada da função
criar_base_dados("MinhaLojaBonita")
