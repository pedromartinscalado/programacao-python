# 3. Criar Tabela 
# Desenvolva um script Python que crie uma tabela chamada clientes 
# dentro da base de dados MinhaLojaBonita, com os campos:
# Id (inteiro, chave primária, auto-incrementado);
# Nome (texto, não nulo);
# Telefone (número inteiro com 9 dígitos);
# Email (texto, não nulo);
# Localidade Nome (texto, não nulo);

import mysql.connector

def criar_tabela_clientes(nome_base_dados, host="localhost", user="root", password=""):
    """
    Cria a tabela 'clientes' na base de dados especificada, caso ainda não exista.

    Args:
        nome_base_dados (str): O nome da base de dados.
        host (str): O endereço do servidor MySQL (padrão: "localhost").
        user (str): O nome de usuário do MySQL.
        password (str): A senha do MySQL.
    """
    try:
        conexao = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=nome_base_dados
        )
        cursor = conexao.cursor()

        # Verifica se a tabela já existe
        cursor.execute("SHOW TABLES LIKE 'clientes'")
        tabela_existe = cursor.fetchone()

        if tabela_existe:
            print("⚠️ A tabela 'clientes' já existe.")
        else:
            # Comando SQL para criar a tabela 'clientes'
            comando_sql = """
            CREATE TABLE clientes (
                Id INT AUTO_INCREMENT PRIMARY KEY,
                Nome VARCHAR(255) NOT NULL,
                Telefone INT UNSIGNED NOT NULL UNIQUE,
                Email VARCHAR(255) NOT NULL,
                Localidade VARCHAR(255) NOT NULL
            )
            """

            cursor.execute(comando_sql)
            print("✅ Tabela 'clientes' criada com sucesso!")

    except mysql.connector.Error as erro:
        print(f"❌ Erro ao criar a tabela 'clientes': {erro}")

    finally:
        if 'conexao' in locals() and conexao.is_connected():
            cursor.close()
            conexao.close()
            print("🔒 Conexão com a base de dados fechada.")

nome_base_dados = "MinhaLojaBonita"
criar_tabela_clientes(nome_base_dados)