# 4. Inserir Registos 
# Desenvolva um programa que permita inserir registos na tabela clientes, garantindo:
# Validação de campos (Nome não pode ser vazio, Email válido, Telefone com 9 dígitos);
# Inserção de múltiplos registos.

import mysql.connector
import re

def validar_email(email):
    """Valida se um email tem um formato válido."""
    regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return re.match(regex, email)

def validar_telefone(telefone):
    """Valida se um telefone tem exatamente 9 dígitos numéricos."""
    return telefone.isdigit() and len(telefone) == 9

def inserir_registos(nome_base_dados, registos, host="localhost", user="root", password=""):
    """
    Insere múltiplos registos na tabela 'clientes' com validação e verificação de duplicação.

    Args:
        nome_base_dados (str): O nome da base de dados.
        registos (list): Lista de dicionários contendo os dados dos clientes.
        host (str): O endereço do servidor MySQL (padrão: "localhost").
        user (str): O nome de usuário do MySQL (padrão: "root").
        password (str): A senha do MySQL.
    """
    try:
        conexao = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=nome_base_dados
        )
        cursor = conexao.cursor()

        registos_validos = []
        
        for registo in registos:
            nome = registo.get("Nome", "").strip()
            telefone = registo.get("Telefone", "").strip()
            email = registo.get("Email", "").strip()
            localidade = registo.get("Localidade", "").strip()

            # Validação dos campos
            if not nome:
                print("❌ Erro: Nome não pode ser vazio.")
                continue
            if not validar_email(email):
                print(f"❌ Erro: Email '{email}' inválido.")
                continue
            if not validar_telefone(telefone):
                print(f"❌ Erro: Telefone '{telefone}' inválido. Deve ter exatamente 9 dígitos numéricos.")
                continue

            # Verificar duplicação antes de inserir
            cursor.execute("SELECT 1 FROM clientes WHERE Email = %s OR Telefone = %s", (email, telefone))
            if cursor.fetchall():  # Se houver resultados, já existe um registo
                print(f"⚠️ Registo ignorado: O email '{email}' ou telefone '{telefone}' já está cadastrado.")
                continue

            registos_validos.append((nome, telefone, email, localidade))

        # Inserção otimizada em lote
        if registos_validos:
            comando_sql = """
            INSERT INTO clientes (Nome, Telefone, Email, Localidade)
            VALUES (%s, %s, %s, %s)
            """
            cursor.executemany(comando_sql, registos_validos)
            conexao.commit()
            print(f"✅ {len(registos_validos)} registo(s) inserido(s) com sucesso!")

    except mysql.connector.Error as erro:
        print(f"❌ Erro ao inserir registos: {erro}")
        conexao.rollback()

    finally:
        if 'conexao' in locals() and conexao.is_connected():
            cursor.close()
            conexao.close()
            print("🔒 Conexão ao MySQL foi fechada.")


# Chamar a função
nome_base_dados = "MinhaLojaBonita"
registos = [
    {"Nome": "João Silva", "Telefone": "123456789", "Email": "joao@email.com", "Localidade": "Lisboa"},
    {"Nome": "Maria Oliveira", "Telefone": "987654321", "Email": "maria@exemplo.pt", "Localidade": "Porto"},
    {"Nome": "Carlos Pereira", "Telefone": "222334455", "Email": "carlos@gmail.com", "Localidade": "Coimbra"},
    {"Nome": "Rui Nogueira", "Telefone": "111222333", "Email": "rui@email.com", "Localidade": "Aveiro"},  
    {"Nome": "Sofia Mendes", "Telefone": "444555666", "Email": "sofia@email.com", "Localidade": "Setúbal"}  
]

inserir_registos(nome_base_dados, registos)
