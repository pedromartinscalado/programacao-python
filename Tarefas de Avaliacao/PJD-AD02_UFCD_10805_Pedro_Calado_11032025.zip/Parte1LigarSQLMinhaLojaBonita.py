# 2. Ligar ao MySQL Desenvolva um programa Python 
# que estabeleça uma ligação à base de dados 
# MinhaLojaBonita usando a biblioteca mysql.connector.

import mysql.connector

def conectar_base_dados(nome_base_dados, host="localhost", user="root", password=""):
    """
    Estabelece uma conexão com a base de dados MySQL especificada.

    Args:
        nome_base_dados (str): O nome da base de dados.
        host (str): O endereço do servidor MySQL (padrão: "localhost").
        user (str): O nome de usuário do MySQL (padrão: "root").
        password (str): A senha do MySQL (padrão: "").

    Returns:
        mysql.connector.connection.MySQLConnection: O objeto de conexão, ou None em caso de erro.
    """
    try:
        conexao = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=nome_base_dados
        )
        print(f"✅ Conexão com a base de dados '{nome_base_dados}' estabelecida com sucesso!")
        return conexao

    except mysql.connector.Error as erro:
        print(f"❌ Erro ao conectar à base de dados '{nome_base_dados}': {erro}")
        return None


# Chamar a função
nome_base_dados = "MinhaLojaBonita"
conexao = conectar_base_dados(nome_base_dados)

# Se a conexão foi estabelecida, podemos executar operações na base de dados
if conexao:
    try:
        cursor = conexao.cursor()

        # Executa uma consulta de teste
        cursor.execute("SELECT 1")
        resultado = cursor.fetchone()
        print(f"🔍 Resultado da consulta: {resultado}")

    except mysql.connector.Error as erro:
        print(f"⚠️ Erro ao executar a consulta: {erro}")

    finally:
        # Fecha o cursor e a conexão
        if conexao.is_connected():
            cursor.close()
            conexao.close()
            print("🔒 Conexão com a base de dados fechada.")
