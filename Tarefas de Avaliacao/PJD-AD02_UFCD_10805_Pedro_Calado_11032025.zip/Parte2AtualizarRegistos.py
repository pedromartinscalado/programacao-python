# 8. Atualizar Registos 
# Crie um programa que permita atualizar 
# o campo Telefone de um cliente com base no seu Id, 
# garantindo que o novo número tem exatamente 9 dígitos.

import streamlit as st
import mysql.connector
import re  # Para validação de email

def validar_telefone(telefone):
    """Valida se um telefone tem exatamente 9 dígitos numéricos."""
    return telefone.isdigit() and len(telefone) == 9

def atualizar_telefone_cliente_db(nome_base_dados, cliente_id, novo_telefone):
    """
    Atualiza o campo 'Telefone' de um cliente na base de dados 'clientes'.

    Args:
        nome_base_dados (str): Nome da base de dados.
        cliente_id (int): ID do cliente a ser atualizado.
        novo_telefone (str): Novo número de telefone para o cliente.

    Returns:
        bool: True se a atualização for bem-sucedida, False em caso de erro.
    """
    conexao = None
    try:
        conexao = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database=nome_base_dados
        )
        cursor = conexao.cursor()

        # Verificar se o cliente com o ID fornecido existe
        comando_sql_select = "SELECT * FROM clientes WHERE Id = %s"
        cursor.execute(comando_sql_select, (cliente_id,))
        cliente = cursor.fetchone()

        if cliente is None:
            st.error(f"Erro: Não existe cliente com o ID {cliente_id} na base de dados.")
            return False

        # Atualizar o telefone do cliente se o cliente existir
        comando_sql_update = "UPDATE clientes SET Telefone = %s WHERE Id = %s"
        valores = (novo_telefone, cliente_id)
        cursor.execute(comando_sql_update, valores)
        conexao.commit()

        if cursor.rowcount > 0:
            st.success(f"Telefone do cliente com ID {cliente_id} atualizado para '{novo_telefone}' com sucesso.")
            return True
        else:
            st.warning(f"Aviso: Nenhum registo foi atualizado para o cliente com ID {cliente_id}. Verifique se o ID está correto.") 
            return False

    except mysql.connector.Error as erro:
        st.error(f"Erro ao atualizar o telefone do cliente na base de dados: {erro}") 
        return False
    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close()
            print("🔒 Conexão ao MySQL fechada.")

# Configuração da página Streamlit
st.set_page_config(page_title="Atualizar Telefone Cliente", page_icon="📞")

st.title("Atualizar Telefone de Cliente")

with st.form("atualizar_telefone_form"):
    cliente_id_input = st.text_input("ID do Cliente a Atualizar:", help="Insira o ID do cliente cujo telefone pretende atualizar.")
    novo_telefone = st.text_input("Novo Telefone (9 dígitos):", help="Insira o novo número de telefone com 9 dígitos.")

    col1, col2, col3 = st.columns([1, 1, 2]) 
    with col3:
        botao_atualizar = st.form_submit_button("Atualizar Telefone")

if botao_atualizar:
    # Validação dos campos
    if not cliente_id_input:
        st.error("O campo 'ID do Cliente a Atualizar' não pode ser vazio.")
    elif not novo_telefone:
        st.error("O campo 'Novo Telefone' não pode ser vazio.")
    elif not validar_telefone(novo_telefone):
        st.error("Número de telefone inválido. Deve ter exatamente 9 dígitos numéricos.")
    else:
        try:
            cliente_id = int(cliente_id_input)
            if cliente_id <= 0:
                st.error("O ID do cliente deve ser um número inteiro positivo.")
            else:
                nome_base_dados = "MinhaLojaBonita" 
                atualizar_telefone_cliente_db(nome_base_dados, cliente_id, novo_telefone) 
        except ValueError:
            st.error("ID de cliente inválido. Por favor, insira um número inteiro válido.")


with st.sidebar:
    st.header("Instruções:")
    st.markdown("""
    **Para atualizar o telefone de um cliente:**

    1.  Insira o **ID do Cliente a Atualizar** (certifique-se de que é um ID válido que existe na base de dados).
    2.  Insira o **Novo Telefone** com exatamente **9 dígitos numéricos**.
    3.  Clique no botão **"Atualizar Telefone"**.
    4.  Verá uma mensagem de **sucesso** a verde se o telefone for atualizado, ou uma mensagem de **erro** a vermelho se algo correr mal (ID inválido, telefone inválido, erro na base de dados, etc.).

    **Nota:** Certifique-se de que a base de dados **'MinhaLojaBonita'** e a tabela **'clientes'** já foram criadas no seu servidor MySQL antes de usar esta aplicação.
    """)