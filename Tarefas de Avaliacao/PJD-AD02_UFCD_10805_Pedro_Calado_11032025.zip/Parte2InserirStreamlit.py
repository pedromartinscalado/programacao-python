# 7. Inserir com Streamlit 
# Desenvolva uma aplicação em Streamlit para 
# inserir dados na tabela clientes com feedback visual sobre sucesso ou erro.

import streamlit as st
import mysql.connector
import re

def validar_nome(nome):
    """Valida se o nome contém apenas letras, espaços, hífen e apóstrofo e tem comprimento razoável."""
    if not nome.strip(): 
        return False, "O campo 'Nome' não pode ser vazio."
    if len(nome) < 2:
        return False, "O campo 'Nome' deve ter pelo menos 2 caracteres."
    if len(nome) > 255: 
        return False, "O campo 'Nome' não pode ter mais de 255 caracteres."
    regex_nome = r"^[a-zA-ZÀ-ú\s'-]+$" 
    if not re.match(regex_nome, nome):
        return False, "O campo 'Nome' contém caracteres inválidos. Use apenas letras, espaços, hífen e apóstrofo."
    return True, None 

def validar_localidade(localidade):
    """Valida se a localidade não está vazia e tem um comprimento máximo."""
    if not localidade.strip(): 
        return False, "O campo 'Localidade' não pode ser vazio."
    if len(localidade) > 255: 
        return False, "O campo 'Localidade' não pode ter mais de 255 caracteres."
    return True, None 

def validar_email(email):
    """Valida se um email tem um formato básico válido."""
    regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return re.match(regex, email)

def validar_telefone(telefone):
    """Valida se um telefone tem exatamente 9 dígitos numéricos."""
    return telefone.isdigit() and len(telefone) == 9

def inserir_cliente_db(nome_base_dados, nome, telefone, email, localidade):
    """
    Insere um novo cliente na base de dados 'clientes'.

    Args:
        nome_base_dados (str): Nome da base de dados.
        nome (str): Nome do cliente.
        telefone (str): Telefone do cliente.
        email (str): Email do cliente.
        localidade (str): Localidade do cliente.

    Returns:
        bool: True se a inserção for bem-sucedida, False em caso de erro.
    """
    
    conexao = None
    try:
        conexao = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database=nome_base_dados
        )
        cursor = conexao.cursor()
        comando_sql = "INSERT INTO clientes (Nome, Telefone, Email, Localidade) VALUES (%s, %s, %s, %s)"
        valores = (nome, telefone, email, localidade)
        cursor.execute(comando_sql, valores)
        conexao.commit()
        return True
    except mysql.connector.Error as erro:
        st.error(f"Erro ao inserir cliente na base de dados: {erro}")
        return False
    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close()

st.set_page_config(page_title="Inserir Cliente", page_icon="👤")
st.title("Inserir Novo Cliente")

with st.form("inserir_cliente_form"):
    nome = st.text_input("Nome do Cliente:", help="Insira o nome completo do cliente.")
    telefone = st.text_input("Telefone (9 dígitos):", help="Insira o número de telefone com 9 dígitos.")
    email = st.text_input("Email:", help="Insira o endereço de email do cliente.")
    localidade = st.text_input("Localidade:", help="Insira a localidade do cliente.")

    col1, col2, col3 = st.columns([1, 1, 2])
    with col3:
        botao_guardar = st.form_submit_button("Guardar Cliente")


if botao_guardar:
    # Validação do Nome
    nome_valido, mensagem_erro_nome = validar_nome(nome)
    if not nome_valido:
        st.error(mensagem_erro_nome)
    
    # Validação da Localidade
    localidade_valida, mensagem_erro_localidade = validar_localidade(localidade)
    if not localidade_valida:
        st.error(mensagem_erro_localidade)
    
    # Validação do Email
    elif not validar_email(email):
        st.error("Email inválido. Por favor, insira um email no formato correto.")
    # Validação do Telefone (EXISTENTE)
    elif not validar_telefone(telefone): # Adicionei 'elif'
        st.error("Telefone inválido. Deve ter exatamente 9 dígitos numéricos.")
    else:
        nome_base_dados = "MinhaLojaBonita"
        if inserir_cliente_db(nome_base_dados, nome, telefone, email, localidade):
            st.success("Cliente guardado com sucesso!")

with st.sidebar:
    st.header("Instruções:")
    st.markdown("""
    **Para inserir um novo cliente:**

    1.  Preencha todos os campos: **Nome**, **Telefone**, **Email** e **Localidade**.
    2.  Certifique-se de que o **Nome** tem pelo menos 2 caracteres, contém apenas letras, espaços, hífen e apóstrofo.
    3.  Certifique-se de que a **Localidade** não está vazia e não excede 255 caracteres.
    4.  Certifique-se de que o **Telefone** tem exatamente **9 dígitos numéricos** e o **Email** tem um formato válido.
    5.  Clique no botão **"Guardar Cliente"**.
    6.  Verá uma mensagem de **sucesso** a verde se o cliente for guardado, ou uma mensagem de **erro** a vermelho se algo correr mal.

    **Nota:** Certifique-se de que a base de dados **'MinhaLojaBonita'** e a tabela **'clientes'** já foram criadas no seu servidor MySQL antes de usar esta aplicação.
    """)