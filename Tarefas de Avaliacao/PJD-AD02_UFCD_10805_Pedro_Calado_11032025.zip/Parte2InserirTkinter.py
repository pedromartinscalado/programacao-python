# Parte 2: Aplicações Gráficas com Integração de MySQL
# 6. Inserir com Tkinter 
# Desenvolva uma aplicação usando Tkinter 
# para inserir dados na tabela clientes, incluindo: 
# Campos para Nome, Telefone, Email, Localidade e Botão "Guardar" 
# para inserir os dados na base de dados. 
# Insira 5 a 8 registos na tabela clientes através dessa aplicação.

import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
import re  # Para validação de email

def validar_nome(nome):
    """Valida se o nome contém apenas letras, espaços, hífen e apóstrofo e tem comprimento razoável."""
    if not nome.strip(): # Verifica se está vazio
        return False, "O campo 'Nome' não pode ser vazio."
    if len(nome) < 2:
        return False, "O campo 'Nome' deve ter pelo menos 2 caracteres."
    if len(nome) > 255: # Máximo de 255 para consistência com a tabela
        return False, "O campo 'Nome' não pode ter mais de 255 caracteres."
    regex_nome = r"^[a-zA-ZÀ-ú\s'-]+$" # Permite letras, espaços, hífen e apóstrofo (e acentuadas)
    if not re.match(regex_nome, nome):
        return False, "O campo 'Nome' contém caracteres inválidos. Use apenas letras, espaços, hífen e apóstrofo."
    return True, None # Validação bem-sucedida, sem mensagem de erro

def validar_localidade(localidade):
    """Valida se a localidade não está vazia e tem um comprimento máximo."""
    if not localidade.strip(): # Verifica se está vazio
        return False, "O campo 'Localidade' não pode ser vazio."
    if len(localidade) > 255: # Máximo de 255 para consistência com a tabela
        return False, "O campo 'Localidade' não pode ter mais de 255 caracteres."
    return True, None # Validação bem-sucedida, sem mensagem de erro


def validar_email(email):
    """Valida se um email tem um formato básico válido."""
    regex = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return re.match(regex, email)

def validar_telefone(telefone):
    """Valida se um telefone tem exatamente 9 dígitos numéricos."""
    return telefone.isdigit() and len(telefone) == 9

def inserir_cliente_db(nome_base_dados, nome, telefone, email, localidade):
    """
    Insere um novo cliente na base de dados 'clientes'.

    Args:
        nome_base_dados (str): Nome da base de dados.
        nome (str): Nome do cliente.
        telefone (str): Telefone do cliente.
        email (str): Email do cliente.
        localidade (str): Localidade do cliente.

    Returns:
        bool: True se a inserção for bem-sucedida, False em caso de erro.
    """
    conexao = None
    try:
        conexao = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database=nome_base_dados
        )
        cursor = conexao.cursor()
        comando_sql = "INSERT INTO clientes (Nome, Telefone, Email, Localidade) VALUES (%s, %s, %s, %s)"
        valores = (nome, telefone, email, localidade)
        cursor.execute(comando_sql, valores)
        conexao.commit()
        return True
    except mysql.connector.Error as erro:
        print(f"Erro ao inserir cliente: {erro}")
        return False
    finally:
        if conexao and conexao.is_connected():
            cursor.close()
            conexao.close()

def guardar_cliente():
    """Função chamada ao clicar no botão 'Guardar'. Valida os dados e insere na BD."""
    nome = entry_nome.get().strip()
    telefone = entry_telefone.get().strip()
    email = entry_email.get().strip()
    localidade = entry_localidade.get().strip()

    # Validação do Nome
    nome_valido, mensagem_erro_nome = validar_nome(nome)
    if not nome_valido:
        messagebox.showerror("Erro", mensagem_erro_nome)
        return

    # Validação do Email
    if not validar_email(email):
        messagebox.showerror("Erro", "Email inválido. Por favor, insira um email no formato correto.")
        return

    # Validação do Telefone
    if not validar_telefone(telefone):
        messagebox.showerror("Erro", "Telefone inválido. Deve ter exatamente 9 dígitos numéricos.")
        return

    # Validação da Localidade
    localidade_valida, mensagem_erro_localidade = validar_localidade(localidade)
    if not localidade_valida:
        messagebox.showerror("Erro", mensagem_erro_localidade)
        return

    nome_base_dados = "MinhaLojaBonita" # Nome da base de dados
    if inserir_cliente_db(nome_base_dados, nome, telefone, email, localidade):
        messagebox.showinfo("Sucesso", "Cliente guardado com sucesso!")
        # Limpar os campos após a inserção bem-sucedida
        entry_nome.delete(0, tk.END)
        entry_telefone.delete(0, tk.END)
        entry_email.delete(0, tk.END)
        entry_localidade.delete(0, tk.END)
    else:
        messagebox.showerror("Erro", "Falha ao guardar o cliente. Verifique a consola para mais detalhes.")

# Configuração da janela principal Tkinter
janela = tk.Tk()
janela.title("Inserir Cliente - Minha Loja Bonita")

# Layout com estilo mais moderno
estilo = ttk.Style()
estilo.theme_use('clam') # ou 'alt', 'default', 'classic', 'vista', 'xpnative' - experimente para ver qual prefere

# Nome
label_nome = ttk.Label(janela, text="Nome:", font=('Helvetica', 12))
label_nome.grid(row=0, column=0, padx=10, pady=10, sticky="e") # sticky="e" para alinhar à direita
entry_nome = ttk.Entry(janela, font=('Helvetica', 12))
entry_nome.grid(row=0, column=1, padx=10, pady=10, sticky="ew") # sticky="ew" para expandir horizontalmente

# Telefone
label_telefone = ttk.Label(janela, text="Telefone (9 dígitos):", font=('Helvetica', 12))
label_telefone.grid(row=1, column=0, padx=10, pady=10, sticky="e")
entry_telefone = ttk.Entry(janela, font=('Helvetica', 12))
entry_telefone.grid(row=1, column=1, padx=10, pady=10, sticky="ew")

# Email
label_email = ttk.Label(janela, text="Email:", font=('Helvetica', 12))
label_email.grid(row=2, column=0, padx=10, pady=10, sticky="e")
entry_email = ttk.Entry(janela, font=('Helvetica', 12))
entry_email.grid(row=2, column=1, padx=10, pady=10, sticky="ew")

# Localidade
label_localidade = ttk.Label(janela, text="Localidade:", font=('Helvetica', 12))
label_localidade.grid(row=3, column=0, padx=10, pady=10, sticky="e")
entry_localidade = ttk.Entry(janela, font=('Helvetica', 12))
entry_localidade.grid(row=3, column=1, padx=10, pady=10, sticky="ew")

# Botão Guardar
botao_guardar = ttk.Button(janela, text="Guardar Cliente", command=guardar_cliente, style='BotaoGuardar.TButton')
botao_guardar.grid(row=4, column=0, columnspan=2, pady=20)

# Estilo para o botão Guardar (opcional - pode personalizar cores, etc.)
estilo.configure('BotaoGuardar.TButton',
font=('Helvetica', 12, 'bold'),
foreground='white',
background='#4CAF50', # Cor verde
padding=10,
borderwidth=0,
relief='flat'
)
estilo.map('BotaoGuardar.TButton',
background=[('active', '#43A047')] # Cor verde mais escura quando ativo
)


# Configurar a janela para expandir bem os widgets
janela.columnconfigure(1, weight=1) # A coluna 1 (dos Entry) expande-se com a janela


janela.mainloop()