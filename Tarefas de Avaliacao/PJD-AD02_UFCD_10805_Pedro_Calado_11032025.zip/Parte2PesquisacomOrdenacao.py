# 9. Pesquisa com Ordenação 
# Desenvolva uma aplicação que liste todos os registos da tabela clientes, 
# permitindo ordenação pelos campos Nome, Localidade ou Email.

import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text  # Importar SQLAlchemy

def obter_clientes_db(nome_base_dados, order_by=None):
    """
    Obtém todos os clientes da base de dados 'clientes' usando SQLAlchemy,
    opcionalmente ordenados por um campo.

    Args:
        nome_base_dados (str): Nome da base de dados.
        order_by (str, optional): Campo para ordenar os resultados ('Nome', 'Localidade', 'Email' ou None para ordem padrão).

    Returns:
        pandas.DataFrame: DataFrame com os dados dos clientes, ou None em caso de erro.
    """
    try:
        # Criar a engine SQLAlchemy (substitua com as suas credenciais se necessário)
        engine = create_engine(f'mysql+mysqlconnector://root:@localhost/{nome_base_dados}') # Usando mysql-connector como driver do SQLAlchemy

        query_sql = "SELECT Id, Nome, Telefone, Email, Localidade FROM clientes"
        if order_by:
            if order_by in ['Nome', 'Localidade', 'Email']:
                query_sql += f" ORDER BY {order_by}"
            else:
                st.warning(f"Campo para ordenação '{order_by}' inválido. A ordenar por ordem padrão.")
        elif order_by is not None: # order_by foi explicitamente definido como None (sem ordenação)
            pass # Mantém a ordem padrão da base de dados (geralmente por ID)

        # Usar a engine SQLAlchemy com pd.read_sql_query
        with engine.connect() as conexao: # Usar um context manager para garantir que a conexão é fechada
            df_clientes = pd.read_sql_query(text(query_sql), conexao) # Passar a query como texto SQLAlchemy
        return df_clientes

    except Exception as erro: # Capturar exceções mais genéricas (SQLAlchemy pode lançar diferentes tipos)
        st.error(f"Erro ao obter clientes da base de dados: {erro}")
        return None
    finally:
        # Com SQLAlchemy, a conexão é geralmente gerida pelo engine e context manager,
        # não precisa de fechar explicitamente aqui neste exemplo simples.
        pass


# Configuração da página Streamlit
st.set_page_config(page_title="Listagem de Clientes", page_icon="👥")
st.title("Listagem de Clientes da Minha Loja Bonita")

nome_base_dados = "MinhaLojaBonita" # Nome da base de dados

# Opções de ordenação para o selectbox
opcoes_ordenacao = ["Sem Ordenação", "Nome", "Localidade", "Email"]
ordenacao_selecionada = st.selectbox("Ordenar por:", opcoes_ordenacao)

# Determinar o campo de ordenação com base na seleção do utilizador
campo_ordenacao = None
if ordenacao_selecionada == "Nome":
    campo_ordenacao = "Nome"
elif ordenacao_selecionada == "Localidade":
    campo_ordenacao = "Localidade"
elif ordenacao_selecionada == "Email":
    campo_ordenacao = "Email"
# Se "Sem Ordenação" for selecionado, campo_ordenacao permanece None, e a função SQL usa a ordem padrão

# Obter os clientes da base de dados, aplicando a ordenação selecionada
df_clientes = obter_clientes_db(nome_base_dados, campo_ordenacao)

if df_clientes is not None:
    if not df_clientes.empty:
        st.dataframe(df_clientes) # Mostra a tabela de clientes no Streamlit
    else:
        st.info("Não existem clientes registados na base de dados.")
else:
    st.error("Falha ao carregar a lista de clientes. Verifique a conexão com a base de dados.")

# Instruções na sidebar
with st.sidebar:
    st.header("Instruções:")
    st.markdown("""
    **Para listar e ordenar os clientes:**

    1.  **Escolha uma opção de ordenação** no menu dropdown "**Ordenar por**" (opções: Sem Ordenação, Nome, Localidade, Email).
    2.  A lista de clientes será automaticamente atualizada e exibida na tabela, ordenada pelo campo selecionado (ou na ordem padrão se "Sem Ordenação" for escolhido).
    3.  Se não existirem clientes registados, será exibida uma mensagem informativa.
    4.  Se ocorrer um erro ao carregar os clientes (e.g., problema de conexão com a base de dados), será exibida uma mensagem de erro.

    **Nota:** Certifique-se de que a base de dados **'MinhaLojaBonita'** e a tabela **'clientes'** já foram criadas e contêm dados no seu servidor MySQL antes de usar esta aplicação.
    """)