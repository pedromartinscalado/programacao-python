# 12. Dashboard de Estatísticas 
# Crie um painel de estatísticas em Streamlit, mostrando:
# o
# Número total de clientes;
# o
# Total de clientes por localidade;
# o
# Média de caracteres nos nomes dos clientes.


import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text

# --- Funções de Banco de Dados ---
def criar_tabela_clientes(engine):
    """Cria a tabela 'clientes' se ela não existir."""
    with engine.connect() as conexao:
        conexao.execute(text("""
            CREATE TABLE IF NOT EXISTS clientes (
                Id INT AUTO_INCREMENT PRIMARY KEY,
                Nome VARCHAR(255) NOT NULL,
                Localidade VARCHAR(255)
            )
        """))
        conexao.commit()

def obter_numero_total_clientes(engine):
    """Obtém o número total de clientes na tabela 'clientes'."""
    with engine.connect() as conexao:
        result = conexao.execute(text("SELECT COUNT(*) FROM clientes"))
        total_clientes = result.scalar() # Obtém o valor único (COUNT(*))
        return total_clientes if total_clientes else 0 # Retorna 0 se não houver clientes

def obter_clientes_por_localidade(engine):
    """Obtém o número de clientes agrupados por localidade."""
    with engine.connect() as conexao:
        result = conexao.execute(text("""
            SELECT Localidade, COUNT(*) as TotalClientes FROM clientes
            GROUP BY Localidade
            ORDER BY Localidade
        """))
        localidades_clientes = []
        for row in result:
            localidades_clientes.append(dict(row._mapping))
        return localidades_clientes

def obter_media_comprimento_nomes_clientes(engine):
    """Calcula a média do comprimento dos nomes dos clientes."""
    with engine.connect() as conexao:
        result = conexao.execute(text("SELECT AVG(LENGTH(Nome)) FROM clientes"))
        media_comprimento = result.scalar()
        return round(media_comprimento, 2) if media_comprimento else 0 # Arredonda para 2 casas decimais


# --- Configuração da Página Streamlit ---
st.set_page_config(page_title="Dashboard de Estatísticas de Clientes", page_icon="📊")
st.title("Dashboard de Estatísticas de Clientes")

nome_base_dados = "MinhaLojaBonita" # Nome da sua base de dados
engine = create_engine(f'mysql+mysqlconnector://root:@localhost/{nome_base_dados}')

# Criar tabela clientes se não existir (apenas para demonstração, pode já existir)
criar_tabela_clientes(engine)

st.header("Estatísticas Gerais de Clientes")

# 1. Número Total de Clientes
total_clientes = obter_numero_total_clientes(engine)
st.metric("Número Total de Clientes", value=total_clientes)

# 2. Total de Clientes por Localidade
st.subheader("Clientes por Localidade")
clientes_por_localidade = obter_clientes_por_localidade(engine)
if clientes_por_localidade:
    df_localidades = pd.DataFrame(clientes_por_localidade)
    st.dataframe(df_localidades, use_container_width=True)
else:
    st.info("Não existem clientes registados para mostrar por localidade.")

# 3. Média de Caracteres nos Nomes dos Clientes
media_nomes = obter_media_comprimento_nomes_clientes(engine)
# Correção: Converter para float antes de passar para st.metric
st.metric("Média de Caracteres nos Nomes dos Clientes", value=float(media_nomes))


# --- Instruções na Sidebar ---
with st.sidebar:
    st.header("Instruções:")
    st.markdown("""
    **Dashboard de Estatísticas de Clientes:**

    Este painel exibe estatísticas sobre os clientes registados na base de dados **'MinhaLojaBonita'**, na tabela **'clientes'**.

    **Estatísticas Apresentadas:**

    *   **Número Total de Clientes:**  Mostra o número total de clientes registados na base de dados.
    *   **Clientes por Localidade:** Exibe uma tabela que mostra o número de clientes para cada localidade registada.
    *   **Média de Caracteres nos Nomes dos Clientes:** Apresenta a média do número de caracteres dos nomes de todos os clientes.

    **Nota:**

    *   Certifique-se de que a base de dados **'MinhaLojaBonita'** e a tabela **'clientes'** (será criada automaticamente se não existir para fins de demonstração) estão corretamente configuradas no seu servidor MySQL/MariaDB.
    *   Para que este dashboard funcione corretamente, a sua tabela **'clientes'** deve ter pelo menos as colunas **'Nome'** (com os nomes dos clientes) e **'Localidade'** (com a localidade de cada cliente).
    *   As estatísticas são calculadas em tempo real com base nos dados presentes na tabela **'clientes'** da base de dados.
    """)