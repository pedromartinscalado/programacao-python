# 11. Gestão de Produtos 
# Crie uma aplicação que permita gerir uma tabela de produtos. 
# A aplicação deve:
# o
# Criar uma tabela produtos com os campos Id, Nome, Preço e Stock;
# o
# Permitir inserir novos produtos;
# o
# Editar os dados de um produto existente;
# o
# Apagar produtos da base de dados.


import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text

# --- Funções de Banco de Dados ---
def criar_tabela_produtos(engine):
    """Cria a tabela 'produtos' se ela não existir."""
    with engine.connect() as conexao:
        conexao.execute(text("""
            CREATE TABLE IF NOT EXISTS produtos (
                Id INT AUTO_INCREMENT PRIMARY KEY,
                Nome VARCHAR(255) NOT NULL,
                Preço DECIMAL(10, 2) NOT NULL,
                Stock INT NOT NULL,
                UNIQUE (Nome) -- Adiciona índice UNIQUE para o nome
            )
        """))
        conexao.commit()

def inserir_produto(engine, nome, preco, stock):
    """Insere um novo produto na tabela 'produtos'."""
    try: # Adiciona tratamento de exceção para unicidade do nome
        with engine.connect() as conexao:
            conexao.execute(text("""
                INSERT INTO produtos (Nome, Preço, Stock)
                VALUES (:nome, :preco, :stock)
            """), {"nome": nome, "preco": preco, "stock": stock})
            conexao.commit()
        return True # Indica inserção bem-sucedida
    except Exception as erro:
        if "Duplicate entry" in str(erro): # Detecta erro de duplicidade do nome (MySQL)
            st.error(f"Erro ao inserir produto: Já existe um produto com o nome '{nome}'. Por favor, use outro nome.")
        else:
            st.error(f"Erro inesperado ao inserir produto: {erro}") # Outros erros
        return False # Indica falha na inserção


def obter_produtos(engine):
    """Obtém todos os produtos da tabela 'produtos'."""
    with engine.connect() as conexao:
        result = conexao.execute(text("SELECT Id, Nome, Preço, Stock FROM produtos"))
        produtos = []
        for row in result:
            produtos.append(dict(row._mapping)) # Converte RowProxy para dicionário
        return produtos

def obter_produto_por_id(engine, produto_id):
    """Obtém um produto da tabela 'produtos' pelo seu ID."""
    with engine.connect() as conexao:
        result = conexao.execute(text("""
            SELECT Id, Nome, Preço, Stock FROM produtos WHERE Id = :produto_id
        """), {"produto_id": produto_id})
        produto = result.fetchone()
        if produto:
            return dict(produto._mapping) # Converte RowProxy para dicionário
        return None

def atualizar_produto(engine, produto_id, nome, preco, stock):
    """Atualiza os dados de um produto existente na tabela 'produtos'."""
    try: # Adiciona tratamento de exceção para unicidade do nome na edição
        with engine.connect() as conexao:
            conexao.execute(text("""
                UPDATE produtos
                SET Nome = :nome, Preço = :preco, Stock = :stock
                WHERE Id = :produto_id
            """), {"produto_id": produto_id, "nome": nome, "preco": preco, "stock": stock})
            conexao.commit()
        return True # Indica atualização bem-sucedida
    except Exception as erro:
        if "Duplicate entry" in str(erro): # Detecta erro de duplicidade do nome (MySQL)
            st.error(f"Erro ao atualizar produto: Já existe outro produto com o nome '{nome}'. Por favor, use outro nome.")
        else:
            st.error(f"Erro inesperado ao atualizar produto: {erro}") # Outros erros
        return False # Indica falha na atualização


def apagar_produto(engine, produto_id):
    """Apaga um produto da tabela 'produtos' pelo seu ID."""
    with engine.connect() as conexao:
        conexao.execute(text("""
            DELETE FROM produtos WHERE Id = :produto_id
        """), {"produto_id": produto_id})
        conexao.commit()

def nome_contem_letra(nome_produto):
    """Verifica se o nome do produto contém pelo menos uma letra."""
    for char in nome_produto:
        if char.isalpha(): # Verifica se o caractere é uma letra
            return True
    return False


# --- Configuração da Página Streamlit ---
st.set_page_config(page_title="Gestão de Produtos", page_icon="📦")
st.title("Gestão de Produtos da Loja")

nome_base_dados = "MinhaLojaBonita" # Nome da sua base de dados
engine = create_engine(f'mysql+mysqlconnector://root:@localhost/{nome_base_dados}')

# Criar tabela produtos se não existir
criar_tabela_produtos(engine)

st.sidebar.header("Ações")
acao = st.sidebar.selectbox("Escolha uma ação:", ["Inserir Produto", "Editar Produto", "Apagar Produto", "Listar Produtos"])

if acao == "Inserir Produto":
    st.header("Inserir Novo Produto")
    with st.form("inserir_produto_form"):
        nome = st.text_input("Nome do Produto:")
        preco = st.number_input("Preço:", min_value=0.01, format="%.2f")
        stock = st.number_input("Stock:", min_value=1, step=1) # Alteração: min_value=1 para stock
        submitted = st.form_submit_button("Inserir Produto") # Correção: Remove key

        if submitted:
            if not nome:
                st.error("O nome do produto é obrigatório.")
            elif len(nome) > 255: # Validação existente: Comprimento do nome
                st.error("O nome do produto não pode ter mais de 255 caracteres.")
            elif not nome_contem_letra(nome): # Validação existente: Nome deve conter pelo menos uma letra
                st.error("O nome do produto deve conter pelo menos uma letra.")
            elif preco <= 0: # Validação existente: Preço > 0
                st.error("O preço deve ser maior que zero.")
            elif stock <= 0: # NOVA validação: Stock > 0 (alterado para <= 0)
                st.error("O stock deve ser maior que zero.")
            else:
                if inserir_produto(engine, nome, preco, stock): # Chama inserir_produto e verifica o retorno
                    st.success(f"Produto '{nome}' inserido com sucesso!")


elif acao == "Editar Produto":
    st.header("Editar Produto Existente")
    produtos_lista = obter_produtos(engine)
    if not produtos_lista:
        st.info("Não existem produtos registados para editar.")
    else:
        produto_selecionado_id = st.selectbox("Selecione o produto para editar:", [p['Id'] for p in produtos_lista], format_func=lambda id_produto: f"ID: {id_produto} - {obter_produto_por_id(engine, id_produto)['Nome']}")
        produto_para_editar = obter_produto_por_id(engine, produto_selecionado_id)

        if produto_para_editar:
            with st.form("editar_produto_form"):
                nome = st.text_input("Nome do Produto:", value=produto_para_editar['Nome'])
                preco = st.number_input("Preço:", min_value=0.01, format="%.2f", value=float(produto_para_editar['Preço'])) # Converter para float
                # Correção para StreamlitValueBelowMinError: Garante que o valor inicial de stock é >= 1
                initial_stock_value = produto_para_editar['Stock'] if produto_para_editar['Stock'] >= 1 else 1
                stock = st.number_input("Stock:", min_value=1, step=1, value=initial_stock_value) # Alteração: min_value=1 para stock
                submitted_editar = st.form_submit_button("Salvar Alterações") # Correção: Remove key

                if submitted_editar:
                    if not nome:
                        st.error("O nome do produto é obrigatório.")
                    elif len(nome) > 255: # Validação existente: Comprimento do nome
                        st.error("O nome do produto não pode ter mais de 255 caracteres.")
                    elif not nome_contem_letra(nome): # Validação existente: Nome deve conter pelo menos uma letra
                        st.error("O nome do produto deve conter pelo menos uma letra.")
                    elif preco <= 0: # Validação existente: Preço > 0
                        st.error("O preço deve ser maior que zero.")
                    elif stock <= 0: # NOVA validação: Stock > 0 (alterado para <= 0)
                        st.error("O stock deve ser maior que zero.")
                    else:
                        if atualizar_produto(engine, produto_selecionado_id, nome, preco, stock): # Chama atualizar_produto e verifica o retorno
                            st.success(f"Produto '{nome}' (ID: {produto_selecionado_id}) atualizado com sucesso!")


elif acao == "Apagar Produto":
    st.header("Apagar Produto")
    produtos_lista = obter_produtos(engine)
    if not produtos_lista:
        st.info("Não existem produtos registados para apagar.")
    else:
        produto_para_apagar_id = st.selectbox("Selecione o produto para apagar:", [p['Id'] for p in produtos_lista], format_func=lambda id_produto: f"ID: {id_produto} - {obter_produto_por_id(engine, id_produto)['Nome']}")

        if st.button("Apagar Produto", key="apagar_button"): # Adicionar key para evitar problemas de ID duplicado se o botão for re-renderizado
            apagar_produto(engine, produto_para_apagar_id)
            st.success(f"Produto com ID: {produto_para_apagar_id} apagado com sucesso!")

elif acao == "Listar Produtos":
    st.header("Listagem de Produtos")
    produtos_lista = obter_produtos(engine)
    if not produtos_lista:
        st.info("Não existem produtos registados.")
    else:
        df_produtos = pd.DataFrame(produtos_lista)
        st.dataframe(df_produtos, use_container_width=True)

# --- Instruções na Sidebar ---
with st.sidebar:
    st.header("Instruções:")
    st.markdown("""
    **Gestão de Produtos da Loja (com Validações Avançadas):**

    Esta aplicação permite gerir a tabela de produtos da base de dados **'MinhaLojaBonita'** e agora inclui validações mais robustas para garantir a qualidade dos dados.

    **Funcionalidades:**

    *   **Inserir Produto:** Adiciona um novo produto à tabela. Preenche o nome (máximo 255 caracteres, único, deve conter pelo menos uma letra), preço (maior que 0) e **stock (maior que 0)** e clique em "**Inserir Produto**". Validações são aplicadas para garantir dados corretos e evitar nomes duplicados.
    *   **Editar Produto:** Permite modificar os dados de um produto existente. Selecione o produto, altere os campos (Nome - máximo 255 caracteres, único, deve conter pelo menos uma letra; Preço - maior que 0; **Stock - maior que 0**) e clique em "**Salvar Alterações**". Validações também são aplicadas na edição.
    *   **Apagar Produto:** Remove um produto da tabela. Selecione o produto que pretende apagar da lista e clique em "**Apagar Produto**".
    *   **Listar Produtos:** Exibe uma tabela com todos os produtos registados na base de dados.

    **Novas Validações Implementadas:**

    *   **Comprimento do Nome:** O nome do produto não pode ter mais de 255 caracteres.
    *   **Unicidade do Nome:**  Não é permitido inserir ou editar um produto com um nome que já exista na base de dados (para garantir que cada produto tenha um nome único).
    *   **Nome Contém Letra:** O nome do produto deve conter pelo menos uma letra (caractere alfabético). Nomes compostos apenas por números não são permitidos.
    *   **Stock Positivo:** O stock do produto deve ser **maior que zero**. Não são permitidos stocks iguais a zero ou negativos.

    **Nota:**

    *   Certifique-se de que a base de dados **'MinhaLojaBonita'** e a tabela **'produtos'** (será criada automaticamente se não existir) estão corretamente configuradas no seu servidor MySQL/MariaDB.
    *   As alterações são refletidas diretamente na base de dados.
    *   As validações ajudam a garantir a qualidade e a consistência dos dados dos produtos.
    """)