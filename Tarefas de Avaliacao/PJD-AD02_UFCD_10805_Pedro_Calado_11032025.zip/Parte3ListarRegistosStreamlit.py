# Parte 3: Desafios Avançados
# 10.
# Listar Registos com Streamlit 
# Desenvolva uma aplicação em Streamlit que liste todos os registos da tabela clientes. A aplicação deve permitir:
# o
# Exibir os registos de forma paginada;
# o
# Filtrar os registos por Nome ou Localidade;
# o
# Atualizar automaticamente os dados exibidos ao inserir ou remover um cliente.

import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text

def obter_clientes_paginado_filtrado(nome_base_dados, pagina, registos_por_pagina, filtro_nome=None, filtro_localidade=None):
    """
    Obtém clientes da base de dados 'clientes' com paginação e filtragem.

    Args:
        nome_base_dados (str): Nome da base de dados.
        pagina (int): Número da página a exibir.
        registos_por_pagina (int): Número de registos por página.
        filtro_nome (str, opcional): Termo para filtrar por nome.
        filtro_localidade (str, opcional): Termo para filtrar por localidade.

    Returns:
        tuple: (pandas.DataFrame, int) - DataFrame com clientes da página atual e total de registos após filtragem.
    """
    try:
        engine = create_engine(f'mysql+mysqlconnector://root:@localhost/{nome_base_dados}')
        offset = (pagina - 1) * registos_por_pagina # Calcular o OFFSET para a paginação

        query_sql = "SELECT Id, Nome, Telefone, Email, Localidade FROM clientes WHERE 1=1" # WHERE 1=1 para facilitar a adição de filtros

        parametros = {} # Dicionário para parâmetros da query (para evitar SQL injection)

        if filtro_nome:
            query_sql += " AND Nome LIKE :filtro_nome"
            parametros['filtro_nome'] = f"%{filtro_nome}%" # % para LIKE (contém)
        if filtro_localidade:
            query_sql += " AND Localidade LIKE :filtro_localidade"
            parametros['filtro_localidade'] = f"%{filtro_localidade}%" # % para LIKE (contém)

        # Query para obter o total de registos APÓS filtragem
        query_total_registos_sql = "SELECT COUNT(*) FROM clientes WHERE 1=1"
        if filtro_nome:
            query_total_registos_sql += " AND Nome LIKE :filtro_nome"
        if filtro_localidade:
            query_total_registos_sql += " AND Localidade LIKE :filtro_localidade"


        query_sql += " LIMIT :limit OFFSET :offset" # Adicionar LIMIT e OFFSET para paginação
        parametros['limit'] = registos_por_pagina
        parametros['offset'] = offset

        with engine.connect() as conexao:
            # Obter os registos da página atual
            df_clientes = pd.read_sql_query(text(query_sql), conexao, params=parametros)
            # Obter o total de registos (para paginação)
            total_registos = pd.read_sql_query(text(query_total_registos_sql), conexao, params=parametros).iloc[0, 0] # Extrair o valor do COUNT

        return df_clientes, total_registos

    except Exception as erro:
        st.error(f"Erro ao obter clientes da base de dados: {erro}")
        return pd.DataFrame(), 0 # Retornar DataFrame vazio e total 0 em caso de erro


# Configuração da página Streamlit
st.set_page_config(page_title="Listagem de Clientes Avançada", page_icon="📊")
st.title("Listagem de Clientes da Minha Loja Bonita (Avançada)")

nome_base_dados = "MinhaLojaBonita"
registos_por_pagina = 2 # Defina quantos registos pretende por página

# Inicializar o estado da página na sessão (para paginação e filtros persistirem entre interações)
if 'pagina_atual' not in st.session_state:
    st.session_state['pagina_atual'] = 1
if 'filtro_nome' not in st.session_state:
    st.session_state['filtro_nome'] = "" # Inicializar filtro de nome vazio
if 'filtro_localidade' not in st.session_state:
    st.session_state['filtro_localidade'] = "" # Inicializar filtro de localidade vazio

# --- Obter dados com paginação e filtros (para calcular total_paginas ANTES da sidebar) ---
df_clientes, total_registos = obter_clientes_paginado_filtrado(
    nome_base_dados,
    st.session_state['pagina_atual'],
    registos_por_pagina,
    st.session_state['filtro_nome'],
    st.session_state['filtro_localidade']
)

total_paginas = (total_registos + registos_por_pagina - 1) // registos_por_pagina # Calcular o total de páginas **AQUI, ANTES DA SIDEBAR**

# --- Sidebar para Filtros e Controlo de Paginação ---
with st.sidebar:
    st.header("Filtros e Navegação")

    st.session_state['filtro_nome'] = st.text_input("Filtrar por Nome:", value=st.session_state['filtro_nome']) # Filtro de nome na sidebar
    st.session_state['filtro_localidade'] = st.text_input("Filtrar por Localidade:", value=st.session_state['filtro_localidade']) # Filtro de localidade na sidebar

    # --- Controlo de Paginação ---
    col_pag_esq, col_pag_dir = st.columns(2) # Dividir a sidebar em 2 colunas para os botões de paginação

    with col_pag_esq: # Coluna para o botão "Anterior"
        if st.button("Página Anterior", key="pagina_anterior_button", disabled=st.session_state['pagina_atual'] <= 1): # Desativar na primeira página
            st.session_state['pagina_atual'] = max(1, st.session_state['pagina_atual'] - 1) # **Correção: Garante que pagina_atual >= 1**

    with col_pag_dir: # Coluna para o botão "Seguinte"
        # (O botão "Seguinte" será desativado/ativado dinamicamente abaixo, após obter o total de páginas)
        if st.button("Página Seguinte", key="pagina_seguinte_button", disabled=st.session_state['pagina_atual'] >= total_paginas): # A desativação do "Seguinte" é controlada depois de obter o total de páginas
            st.session_state['pagina_atual'] += 1

# --- Exibir Tabela de Clientes ---
if not df_clientes.empty:
    st.dataframe(df_clientes, use_container_width=True) # Exibir DataFrame na página principal, ocupar largura total do container

    # --- Informação de Paginação Abaixo da Tabela ---
    col_info_pag, col_num_pag = st.columns([3, 1]) # Dividir o espaço abaixo da tabela em 2 colunas
    with col_info_pag:
        st.markdown(f"Página **{st.session_state['pagina_atual']}** de **{total_paginas}**")
    with col_num_pag:
        pass

else:
    st.info("Não existem clientes registados com os critérios de filtragem atuais.") # Mensagem se não houver clientes com os filtros

with st.sidebar:
    st.header("Instruções:")
    st.markdown("""
    **Listagem de Clientes Avançada:**

    **Funcionalidades:**

    *   **Paginação:** A lista de clientes é dividida em páginas para facilitar a navegação em grandes listas. Use os botões "**Página Anterior**" e "**Página Seguinte**" na barra lateral para navegar entre as páginas.
    *   **Filtragem por Nome e Localidade:** Use os campos "**Filtrar por Nome**" e "**Filtrar por Localidade**" na barra lateral para pesquisar clientes que contenham os termos inseridos nos campos de Nome ou Localidade, respetivamente. A listagem é atualizada automaticamente à medida que escreve nos campos de filtro.

    **Como usar:**

    1.  **Navegar pelas páginas:** Use os botões "**Página Anterior**" e "**Página Seguinte**" na barra lateral para ver diferentes páginas de clientes. Os botões são desativados quando chega à primeira ou à última página.
    2.  **Filtrar por Nome:** Insira um termo no campo "**Filtrar por Nome**" na barra lateral. A lista de clientes será atualizada para mostrar apenas os clientes cujo nome contenha o termo inserido. Deixe o campo vazio para remover o filtro por nome.
    3.  **Filtrar por Localidade:** Insira um termo no campo "**Filtrar por Localidade**" na barra lateral. A lista de clientes será atualizada para mostrar apenas os clientes cuja localidade contenha o termo inserido. Deixe o campo vazio para remover o filtro por localidade.
    4.  **Combinação de Filtros:** Pode usar os filtros de Nome e Localidade em conjunto. A listagem mostrará apenas os clientes que соответem **ambos** os critérios de filtragem (Nome **E** Localidade).

    **Nota:**
    *   A aplicação lista os clientes da base de dados **'MinhaLojaBonita'**, tabela **'clientes'**.
    *   A listagem é atualizada automaticamente quando navega entre páginas ou altera os filtros.
    """)