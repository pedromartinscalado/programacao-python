import streamlit as st
import os 
from streamlit_option_menu import option_menu
from database.database import cria_tabelas  
from painel_admin.painel_admin import painel_admin_page  
from area_utilizador.area_utilizador import login_page
from utils.config import NO_IMAGE_PATH  
from utils.session_manager import init_session_state
from pages_app.home_page import home_page
from pages_app.produtos_page import produtos_page
# from pages_app.adicionar_page import adicionar_page
# from pages_app.editar_page import editar_page
# from pages_app.eliminar_page import eliminar_page
from pages_app.wishlist_page import wishlist_page

# Configuração da página principal do Streamlit
st.set_page_config(page_title="Loja de Moda", page_icon="🛍️", layout="wide")

# Criação do diretório de imagens, se não existir (garantir que existe no inicio da app)
if not os.path.exists("images"):
    os.makedirs("images")

# Criação das tabelas no banco de dados se ainda não existirem
cria_tabelas()  

class MultiApp:
    def __init__(self):
        self.apps = [] # Lista para armazenar as aplicações

    def add_app(self, title, func):
        self.apps.append({"title": title, "function": func})

    def run(self):  
        st.title('Loja de Moda')  # Título principal da aplicação

        with st.sidebar:
            app_options = []  # Inicializa a lista de opções do menu

             # Adiciona as páginas que todos os utilizadores podem visualizar
            self.add_app_conditional(app_options, "Página Inicial", home_page, True)
            self.add_app_conditional(app_options, "Produtos", produtos_page, True)
            if st.session_state.get("logged_in"): # Se o utilizador estiver autenticado
                self.add_app_conditional(app_options, "Wishlist", wishlist_page, True)
            self.add_app_conditional(app_options, "Área de Utilizador", login_page, True)

            # Adiciona as páginas de administração apenas se o utilizador estiver logado e for admin
            if st.session_state.get("logged_in") and st.session_state.get("is_admin"):
                # self.add_app_conditional(app_options, "Adicionar Produto", adicionar_page, True)
                # self.add_app_conditional(app_options, "Editar Produto", editar_page, True)
                # self.add_app_conditional(app_options, "Eliminar Produto", eliminar_page, True)
                self.add_app_conditional(app_options, "Painel Admin", painel_admin_page, True)

            # Exemplo de outras páginas futuras
            # self.add_app_conditional(app_options, "Descontos", descontos_page, True)
            # self.add_app_conditional(app_options, "Mais Vendidos", mais_vendidos_page, True)
            # self.add_app_conditional(app_options, "Marcas", marcas_page, True)
            # self.add_app_conditional(app_options, "Suporte", suporte_page, True)
            # self.add_app_conditional(app_options, "Entregas", entregas_page, True)

             # Exibe mensagem de acesso administrativo
            if st.session_state['is_admin'] == True:
                st.success('Acesso de Administrador')
            
            # Cria o menu lateral de navegação
            app_selection = option_menu(
                menu_title='Menu Principal',
                options=app_options,
                icons=['house', 'bag-check-fill', 'heart-fill', 'person-fill', 'plus-square-fill', 'pencil-square-fill', 'trash-fill', 'gear-fill'],
                menu_icon='cast',
                default_index=0,
            )
        # Executa a aplicação selecionada
        for app_dict in self.apps:
            if app_dict["title"] == app_selection:
                app_dict["function"]()
                break

    def add_app_conditional(self, app_options, title, func, condition):
        if condition:
            self.add_app(title, func)
            app_options.append(title)

# Executa a aplicação principal se este ficheiro for o ponto de entrada
if __name__ == "__main__": 
    init_session_state() # Inicializa o estado da sessão
    app = MultiApp() # Cria uma instância da classe MultiApp
    app.run() # Executa a aplicação