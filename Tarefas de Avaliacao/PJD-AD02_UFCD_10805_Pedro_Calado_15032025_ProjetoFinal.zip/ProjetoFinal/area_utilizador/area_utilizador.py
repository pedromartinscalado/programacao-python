import streamlit as st
import re
import bcrypt
from database.database import get_db_connection
from database.user_db_functions import check_login, regista_utilizador, atualizar_utilizador, lista_utilizadores, logout
import mysql.connector
import time

# Função para adicionar um produto à Wishlist
def adicionar_wishlist(id_produto):
    """Adiciona um produto à wishlist, se ainda não existir."""
    # Verifica se o utilizador está logado
    if st.session_state['logged_in'] == False:
        st.warning("Não tens acesso visto que não estás logado")
    # Verifica se o produto já está na Wishlist
    elif id_produto not in st.session_state["wishlist"]:
        st.session_state["wishlist"].append(id_produto) # Adiciona o produto à Wishlist
        st.success("Produto adicionado à Wishlist!")
    else:
        st.warning("Este produto já está na Wishlist!")


# Função para alterar a password de um utilizador na base de dados
def alterar_password(username, nova_password):
    """
    Altera a password de um utilizador na base de dados.

    Args:
        username (str): O username do utilizador.
        nova_password (str): A nova password a ser definida.

    Returns:
        bool: True se a password foi alterada com sucesso, False caso contrário.
    """
    # 1. Hashing da nova_password usando bcrypt
    hashed_nova_password = bcrypt.hashpw(nova_password.encode('utf-8'), bcrypt.gensalt())

    conn = None
    try:
        # 2. Conectar à base de dados
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor()
            # 3. Query SQL UPDATE para alterar a password_hash na base de dados
            query = "UPDATE utilizadores SET password_hash = %s WHERE username = %s"
            cursor.execute(query, (hashed_nova_password, username))
            conn.commit()  # Commit para salvar as alterações na BD
            cursor.close()
            return True
        else:
            return False
    except Exception as e:
        print(f"Erro ao alterar password na base de dados: {e}")
        return False
    finally:
        if conn:
            conn.close()


# Função para adicionar um utilizador ao sistema
def submit_add_user(new_username, new_password_hash, confirm_password_hash, nome, email, telefone):
    if new_username and new_password_hash and confirm_password_hash and nome and email and telefone:
        # Verificação de se as passwords coincidem
        if new_password_hash != confirm_password_hash:
            st.error("As password não coincidem!")
        elif len(new_password_hash) < 3:
            st.error("A password deve ter pelo menos 3 caracteres.")
        elif regista_utilizador(new_username, new_password_hash, nome, email, telefone):
            st.info("Registo concluído! Faz login para continuar.")
            return True
    else:
        st.error("Por favor, preencha todos os campos.")
    return False


# Função para remover um utilizador do sistema
def remover_utilizador(id_user):
    conn = get_db_connection()
    if conn is None:
        return
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM utilizadores WHERE id = %s", (id_user,))
        conn.commit()
        st.success("Utilizador foi eliminado com sucesso!")
    except mysql.connector.Error as err:
        st.error(f"Erro ao eliminar o utilizador: {err}")
    finally:
        cursor.close()
        conn.close()
    st.session_state.utilizadores = [user for user in st.session_state.utilizadores if user["id"] != id_user]
    st.success(f"Utilizador {id_user} removido com sucesso!")
    st.rerun()

# Função para adicionar um novo utilizador ao sistema
def adicionar_utilizador(username,password_hash, nome, email, telefone):
    if any(user["username"] == username for user in st.session_state.utilizadores):
        st.warning(f"O username '{username}' já existe!")
    else:
        if(submit_add_user(username,password_hash,password_hash,nome,email,telefone)== True):
            st.session_state.utilizadores = lista_utilizadores()  # Atualiza a lista de utilizadores
            st.success(f"Utilizador {username} adicionado com sucesso!")
            time.sleep(1)
            st.rerun()


# Função para editar as informações de um utilizador existente
def editar_utilizador(id, novo_nome, novo_email, novo_telefone):
    if(atualizar_utilizador(id, novo_nome, novo_email, novo_telefone) == True):
        st.session_state.utilizadores = lista_utilizadores() # Atualiza a lista de utilizadores
        st.success(f"Utilizador foi {id} editado com sucesso!")
        time.sleep(1)
        st.rerun()
        

# Função de login e registo de utilizador
def login_page():
    # Inicializa o 'logged_in' se ainda não existir na sessão
    if "logged_in" not in st.session_state:
        st.session_state["logged_in"] = False
    
    st.subheader("Área de Utilizador")

    # Verifica se o utilizador está logado
    if st.session_state["logged_in"]:
        with st.container():
            st.subheader("Perfil de Utilizador")
            st.write(f"Bem-vindo, **{st.session_state['username']}**!")
            st.write("Aqui poderá ver e editar as suas informações de perfil.")
            nome_perfil = st.text_input("Nome Completo", value=st.session_state.get('user_nome', ""))
            email_perfil = st.text_input("Email", value=st.session_state.get('user_email', ""))
            telefone_perfil = st.text_input("Telefone", value=st.session_state.get('user_telefone', ""))

            # Botão para salvar as alterações no perfil
            if st.button("Salvar Perfil", key="btn_salvar_perfil"):
                user_id = st.session_state["user_id"]
                nome = nome_perfil
                email = email_perfil
                telefone = telefone_perfil

                # Valida os dados do perfil
                if not nome.strip():
                    st.error("Por favor, insira o seu Nome Completo.")
                elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                    st.error("Email inválido. Por favor, insira um email no formato correto (ex: exemplo@dominio.com).")
                else:
                    # Atualiza o perfil do utilizador
                    if atualizar_utilizador(user_id, nome, email, telefone):
                        st.success("Perfil atualizado com sucesso!")
                        st.session_state['user_nome'] = nome
                        st.session_state['user_email'] = email
                        st.session_state['user_telefone'] = telefone
                    else:
                        st.error("Erro ao atualizar o perfil. Tente novamente.")
            
            st.write("---")

            # Seção para alteração de password
            st.subheader("Alterar Password")
            password_atual_perfil = st.text_input("Password Atual", type="password")
            nova_password_perfil = st.text_input("Nova Password", type="password")
            confirmar_nova_password_perfil = st.text_input("Confirmar Nova Password", type="password")

        
        # Botão para alterar a password
        if st.button("Alterar Password", key="btn_alterar_password"):
            password_atual = password_atual_perfil
            nova_password = nova_password_perfil
            confirmar_nova_password = confirmar_nova_password_perfil
            user_id = st.session_state["user_id"]

            # Validação dos campos de password
            if not password_atual:
                st.error("Por favor, insira a sua Password Atual para alterar a password.")
            elif not nova_password or not confirmar_nova_password:
                st.error("Por favor, preencha os campos 'Nova Password' e 'Confirmar Nova Password'.")
            elif nova_password != confirmar_nova_password:
                st.error("As novas passwords não coincidem.")
            else:
                conn = get_db_connection()
                if conn:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute("SELECT password_hash FROM utilizadores WHERE id = %s", (user_id,))
                    user_data = cursor.fetchone()
                    cursor.close()
                    conn.close()

                    if user_data:
                        stored_password_hash = user_data['password_hash']
                        # Verifica se a password atual está correta
                        if bcrypt.checkpw(password_atual.encode('utf-8'), stored_password_hash.encode('utf-8')):
                            # Verifica se a nova password não é a mesma que a atual
                            if password_atual != nova_password:
                                username = st.session_state["username"]
                                sucesso_alteracao = alterar_password(username, nova_password)
                                if sucesso_alteracao:
                                    st.success("Password alterada com sucesso!")
                                else:
                                    st.error("Erro ao alterar a password. Por favor, tente novamente.")
                            else:
                                st.error("A tua palavra passe não pode ser a mesma.")
                                
                        else:
                            st.error("Password Atual incorreta. Por favor, tente novamente.")
                    else:
                        st.error("Erro ao verificar password atual. Tente novamente.")
                else:
                    st.error("Erro ao conectar à base de dados.")
        
        # Gerenciamento de utilizadores (apenas admin)  
        if st.session_state.get("is_admin", False):
            st.subheader("Gerir Utilizadores")
            if "utilizadores" not in st.session_state:
                st.session_state.utilizadores = lista_utilizadores()
        
            # Tabela de utilizadores
            st.write("### Lista de Utilizadores")
            for user in st.session_state.utilizadores:
                col1, col2, col3, col4, col5, col6 = st.columns([1, 2, 3, 2, 1, 1])
                col1.write(user["username"])
                col2.write(user["nome"])
                col3.write(user["email"])
                col4.write(user["telefone"])
                if col5.button("✏️", key=f"edit_{user['username']}"):
                    st.session_state["edit_user"] = user 
                if user['is_admin'] == 0:
                    if col6.button("❌", key=f"delete_{user['username']}"): 
                        remover_utilizador(user["id"])

            # Formulário para adicionar utilizadores
            st.write("### Adicionar Novo Utilizador")
            with st.form("adicionar_utilizador"):
                new_username = st.text_input("Username")
                new_password_hash = st.text_input("Password")
                new_nome = st.text_input("Nome")
                new_email = st.text_input("Email")
                new_telefone = st.text_input("Telefone")
                submitted = st.form_submit_button("Adicionar Utilizador")
                if submitted:
                    adicionar_utilizador(new_username, new_password_hash, new_nome, new_email, new_telefone)
                    

            # Formulário para editar utilizadores
            if "edit_user" in st.session_state:
                st.write("### Editar Utilizador")
                with st.form("editar_utilizador"):
                    edit_username = st.session_state["edit_user"]["username"]
                    edit_nome = st.text_input("Nome", st.session_state["edit_user"]["nome"])
                    edit_email = st.text_input("Email", st.session_state["edit_user"]["email"])
                    edit_telefone = st.text_input("Telefone", st.session_state["edit_user"]["telefone"])
                    submitted = st.form_submit_button("Atualizar Utilizador")
                    if submitted:
                        editar_utilizador(st.session_state['edit_user']['id'], edit_nome, edit_email, edit_telefone)
            
            
            # Botão para logout de utilizador admin  
            if st.button("Logout", key="btn_logout_admin"):
                logout()
                st.rerun()
        else:
            st.info("Acesso de Utilizador Regular")
            # Botão para logout de utilizador regular
            if st.button("Logout", key="btn_logout_regular"):
                logout()
                st.rerun()
    else:
        # Exibe os tabs para Login e Registo
        tab1, tab2 = st.tabs(["Login", "Registo"])

        with tab1:
            with st.form("login_form"):
                username = st.text_input("Nome de Utilizador")
                password_hash = st.text_input("Password", type="password")
                submit = st.form_submit_button("Iniciar Sessão")
                if submit:
                    if username and password_hash:
                        if check_login(username, password_hash):
                            st.rerun()
                    else:
                        st.error("Por favor, preencha todos os campos.")

        with tab2:
            with st.form("registo_form"):
                new_username = st.text_input("Nome de Utilizador")
                new_password_hash = st.text_input("Password", type="password")
                confirm_password_hash = st.text_input("Confirmar Password", type="password")
                nome = st.text_input("Nome Completo")
                email = st.text_input("Email")
                telefone = st.text_input("Telefone", max_chars=9)
                submit_registo = st.form_submit_button("Registar")
                if submit_registo:
                    submit_add_user(new_username, new_password_hash, confirm_password_hash, nome, email, telefone)
                