import mysql.connector # Biblioteca para conectar ao MySQL
import streamlit as st # Biblioteca para criar a interface com o usuário
import bcrypt # Biblioteca para fazer hashing de senhas
from utils.config import db_config, NO_IMAGE_PATH # Configurações da base de dados e imagem padrão

# ------------------------------------------------
# 1. CONFIGURAÇÃO INICIAL E CRIAÇÃO DE TABELAS
# ------------------------------------------------

# Função para estabelecer a ligação ao MySQL com tratamento de exceções
def get_db_connection():
    try:
        # Tentativa de conectar ao servidor MySQL
        conn = mysql.connector.connect(host='localhost', user='root', password='')
        cursor = conn.cursor()
        # Cria a base de dados "loja_modas" se não existir
        cursor.execute("CREATE DATABASE IF NOT EXISTS loja_modas")
        cursor.close()
        conn.close()
        
        # Conecta à base de dados com as configurações fornecidas
        conn = mysql.connector.connect(**db_config)
        return conn # Retorna a conexão se bem-sucedida
    except mysql.connector.Error as err:
        # Exibe uma mensagem de erro se ocorrer um erro ao conectar
        st.error(f"Erro ao conectar à base de dados: {err}")
        return None # Retorna None se não conseguir conectar

# Função para criar as tabelas caso não existam
def cria_tabelas():
    # Estabelece a conexão com a base de dados
    conn = get_db_connection()
    if conn is None:
        return # Se não conseguiu conectar, retorna sem fazer nada
    try:
        cursor = conn.cursor()

        # Criação da tabela de produtos, caso não exista
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS produtos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(255) NOT NULL,
                descricao TEXT,
                preco DECIMAL(10,2) NOT NULL,
                imagem VARCHAR(255)
            )
        ''')

        # Criação da tabela de utilizadores, caso não exista
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS utilizadores (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                nome VARCHAR(100),
                email VARCHAR(100) NOT NULL UNIQUE,
                telefone VARCHAR(9) NOT NULL UNIQUE,
                is_admin BOOLEAN DEFAULT FALSE
            )
        ''')

        # Verifica se o utilizador "admin" já existe
        cursor.execute("SELECT * FROM utilizadores WHERE username = 'admin'")
        if not cursor.fetchone():
            # Se não existir, cria o utilizador admin com a password hash
            admin_password = '123'  # Senha inicial para o admin
            hashed_admin_password = bcrypt.hashpw(admin_password.encode('utf-8'), bcrypt.gensalt()) # Faz o hash da senha

            # Insere o utilizador admin na tabela
            cursor.execute(
                "INSERT INTO utilizadores (username, password_hash, nome, email, telefone, is_admin) VALUES (%s, %s, %s, %s, %s, %s)",
                ('admin', hashed_admin_password, 'Administrador', 'admin@exemplo.com', '912345678', True)
            )

        # Confirma a inserção ou alteração na base de dados
        conn.commit()
    except mysql.connector.Error as err:
        # Exibe um erro caso ocorra ao tentar criar as tabelas
        st.error(f"Erro na criação das tabelas: {err}")
    finally:
        # Fecha o cursor e a conexão com a base de dados
        cursor.close()
        conn.close()
        
# Função para listar todos os produtos da base de dados       
def lista_produtos():
    """
    Retorna uma lista de todos os produtos da base de dados.
    """
    conn = get_db_connection() # Estabelece a conexão com a base de dados
    if conn:
        cursor = conn.cursor(dictionary=True) # Usa dicionários para resultados (facilita o acesso por nome de coluna)
        cursor.execute("SELECT * FROM produtos") # Executa a consulta para obter todos os produtos
        produtos = cursor.fetchall() # Obtém todos os resultados da consulta
        conn.close() # Fecha a conexão com a base de dados
        return produtos # Retorna a lista de produtos
    else:
        return [] # Retorna uma lista vazia se não conseguir conectar à base de dados