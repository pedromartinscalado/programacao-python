import streamlit as st  # Para usar st.success e st.error (mensagens de feedback)
import mysql.connector  # Para interagir com a base de dados MySQL
from database.database import get_db_connection # Para obter a conexão com a base de dados

# Função para adicionar um novo produto na base de dados
def adiciona_produto(nome, descricao, preco, imagem):
    conn = get_db_connection() # Obtém a conexão com a base de dados
    if conn is None:
        return # Se não conseguir conectar, retorna sem fazer nada
    try:
        cursor = conn.cursor() # Cria um cursor para executar comandos SQL
        
        # Executa o comando SQL para inserir o novo produto na tabela 'produtos'
        cursor.execute(
            "INSERT INTO produtos (nome, descricao, preco, imagem) VALUES (%s, %s, %s, %s)",
            (nome, descricao, preco, imagem)
        )
        conn.commit() # Confirma a inserção na base de dados
        st.success("Produto adicionado com sucesso!") # Exibe uma mensagem de sucesso
    except mysql.connector.Error as err:
        # Em caso de erro, exibe uma mensagem de erro com a descrição do problema
        st.error(f"Erro ao adicionar produto: {err}")
    finally:
        cursor.close() # Fecha o cursor
        conn.close() # Fecha a conexão com a base de dados

# Função para atualizar um produto existente na base de dados
def atualizar_produto(id_produto, nome, descricao, preco, imagem):
    conn = get_db_connection() # Obtém a conexão com a base de dados
    if conn is None:
        return # Se não conseguir conectar, retorna sem fazer nada
    try:
        cursor = conn.cursor() # Cria um cursor para executar comandos SQL
        
        # Executa o comando SQL para atualizar os dados do produto
        cursor.execute(
            "UPDATE produtos SET nome = %s, descricao = %s, preco = %s, imagem = %s WHERE id = %s",
            (nome, descricao, preco, imagem, id_produto)
        )
        conn.commit() # Confirma as alterações na base de dados
        st.success("Produto atualizado com sucesso!") # Exibe uma mensagem de sucesso
    except mysql.connector.Error as err:
        # Em caso de erro, exibe uma mensagem de erro com a descrição do problema
        st.error(f"Erro ao atualizar produto: {err}")
    finally:
        cursor.close() # Fecha o cursor
        conn.close() # Fecha a conexão com a base de dados

# Função para eliminar um produto da base de dados
def eliminar_produto(id_produto):
    conn = get_db_connection() # Obtém a conexão com a base de dados
    if conn is None:
        return # Se não conseguir conectar, retorna sem fazer nada
    try:
        cursor = conn.cursor() # Cria um cursor para executar comandos SQL
        
        # Executa o comando SQL para deletar o produto com o ID especificado
        cursor.execute("DELETE FROM produtos WHERE id = %s", (id_produto,))
        conn.commit() # Confirma a remoção na base de dados
        st.success("Produto eliminado com sucesso!") # Exibe uma mensagem de sucesso
    except mysql.connector.Error as err:
        # Em caso de erro, exibe uma mensagem de erro com a descrição do problema
        st.error(f"Erro ao eliminar produto: {err}")
    finally:
        cursor.close()  # Fecha o cursor
        conn.close() # Fecha a conexão com a base de dados

# Função para listar todos os produtos da base de dados
def lista_produtos():
    """ Devolve todos os produtos da base de dados. """
    conn = get_db_connection() # Obtém a conexão com a base de dados
    if conn is None:
        return [] # Retorna uma lista vazia se não conseguir conectar
    try:
        cursor = conn.cursor(dictionary=True) # Usa dicionários para retornar os resultados
        cursor.execute("SELECT * FROM produtos") # Executa a consulta para obter todos os produtos
        produtos = cursor.fetchall() # Obtém todos os resultados da consulta
        return produtos
    except mysql.connector.Error as err:
        # Em caso de erro, exibe uma mensagem de erro com a descrição do problema
        st.error(f"Erro ao listar produtos: {err}")
        return [] # Retorna uma lista vazia se houver erro
    finally:
        cursor.close() # Fecha o cursor
        conn.close()  # Fecha a conexão com a base de dados