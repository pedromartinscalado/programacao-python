import streamlit as st # Usado para exibir mensagens no frontend
import mysql.connector # Para interação com o banco de dados MySQL
import bcrypt # Para hash de senhas de forma segura
import re # Para trabalhar com expressões regulares
from database.database import get_db_connection # Função para obter a conexão com o banco de dados

def validar_email(email):
    """Valida o formato do email."""
    regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$' # Regex para verificar se o email tem um formato válido
    if re.match(regex, email):
        return True # Retorna True se o formato do email for válido
    else:
        st.error("O email não é válido, tente como está no exemplo: email@dominio.com") # Exibe uma mensagem de erro se o email for inválido
        #st.error("O email não é válido, exemplo: email@dominio.com %s"%email) # Exibe uma mensagem de erro se o email for inválido
        return False

def validar_telefone(telefone):
    """Valida o formato do telefone (apenas números e no mínimo 9 dígitos)."""
    if telefone.isdigit() and len(telefone) == 9:  # Verifica se o telefone contém apenas números e tem 9 dígitos
        return True  # Retorna True se o telefone for válido
    else:
        st.error("O número de telefone não é válido. Deve conter apenas números e ter pelo menos 9 dígitos.")
        return False # Exibe uma mensagem de erro caso o telefone seja inválido

def valida_nome(nome):
    MAX_NOME_LENGTH = 40 # Define o comprimento máximo do nome
    pattern = r'^[A-Za-zÀ-ÿ\s]+$' # Permite apenas letras e espaços, incluindo caracteres acentuados
    if not nome.strip(): # Verifica se o nome não está vazio
        st.error('Por favor, insira um nome válido para o utilizador.')
        return False
    elif len(nome) > MAX_NOME_LENGTH: # Verifica se o nome não excede o comprimento máximo
        st.error(f'O nome do utilizador não pode ter mais de {MAX_NOME_LENGTH} caracteres.')
        return False
    elif any(char.isdigit() for char in nome): # Verifica se o nome contém números
        st.error('O nome do utilizador não pode conter números.')
        return False    
    elif not re.match(pattern, nome):  # Verifica se o nome contém caracteres inválidos
        st.error('O nome do utilizador não pode conter caracteres inválidos.')
        return False
    elif nome.strip() == "":
        st.error('O nome não pode estar vazio.')
        return False
    return True  # Retorna True se o nome for válido

def regista_utilizador(username, password_hash, nome, email, telefone, is_admin=False):
    """Registra um novo utilizador na base de dados, com validações de email e telefone."""
    if not validar_email(email) or not validar_telefone(telefone):
        return False  # Se o email ou telefone forem inválidos, não regista

    conn = get_db_connection() # Obtém a conexão com a base de dados
    if conn is None:
        return False # Se não conseguir se conectar ao banco de dados, retorna False
    try:
        cursor = conn.cursor()
        # Verifica se o nome de utilizador já existe
        cursor.execute("SELECT * FROM utilizadores WHERE username = %s", (username,))
        if cursor.fetchone():
            st.error("Este nome de utilizador já existe!")
            return False
        # Verifica se o email já está em uso
        cursor.execute("SELECT * FROM utilizadores WHERE email = %s", (email,))
        if cursor.fetchone():
            st.error("Este email do utilizador já existe!")
            return False
        # Verifica se o telefone já está em uso
        cursor.execute("SELECT * FROM utilizadores WHERE telefone = %s", (telefone,))
        if cursor.fetchone():
            st.error("Este número de telefone já existe!")
            return False

        # Faz hash da senha usando bcrypt para segurança
        hashed_password_hash = bcrypt.hashpw(password_hash.encode('utf-8'), bcrypt.gensalt())
        
        # Insere o novo utilizador na base de dados
        cursor.execute(
            "INSERT INTO utilizadores (username, password_hash, nome, email, telefone, is_admin) VALUES (%s, %s, %s, %s, %s, %s)",
            (username, hashed_password_hash, nome, email, telefone, is_admin)   # Guarda a senha de forma segura
        )
        conn.commit() # Confirma a inserção na base de dados
        st.success("Utilizador registado com sucesso!") # Mensagem de sucesso
        return True
    except mysql.connector.Error as err:
        st.error(f"Erro ao registar utilizador: {err}") # Exibe erro em caso de falha na inserção 
        return False
    finally:
        cursor.close() # Fecha o cursor após o uso
        conn.close() # Fecha a conexão com o banco de dados

def check_login(username, password_hash):
    """Verifica as credenciais na base de dados usando bcrypt e retorna dados do utilizador."""
    conn = get_db_connection() # Obtém a conexão com a base de dados
    if conn is None:
        return False # Se a conexão falhar, retorna False
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM utilizadores WHERE username = %s", (username,))
        user = cursor.fetchone() # Obtém os dados do utilizador com o username fornecido
        if user:
            # Verifica se a senha fornecida corresponde ao hash armazenado no banco
            if bcrypt.checkpw(password_hash.encode('utf-8'), user['password_hash'].encode('utf-8')):
                # Se a senha for válida, armazena as informações do utilizador na sessão
                st.session_state["logged_in"] = True
                st.session_state["username"] = username
                st.session_state["user_id"] = user["id"]
                st.session_state["is_admin"] = user["is_admin"]
                st.session_state["user_nome"] = user["nome"]
                st.session_state["user_email"] = user["email"]
                st.session_state["user_telefone"] = user["telefone"]
                st.success(f"Bem-vindo, {username}!")
                return True
            else:
                st.error("Password inválida. Tente novamente.") # Mensagem de erro em caso de senha inválida
                return False
        else:
            st.error("Utilizador não encontrado. Verifique o nome de utilizador.")  # Caso o utilizador não exista
            return False
    except mysql.connector.Error as err:
        st.error(f"Erro ao verificar login: {err}") # Exibe erro em caso de falha na consulta
        return False
    finally:
        cursor.close() # Fecha o cursor
        conn.close() # Fecha a conexão com o banco de dados

def logout():
    """Efetua o logout do utilizador."""
    st.session_state["logged_in"] = False  # Marca o utilizador como não autenticado
    st.session_state["username"] = ""  # Limpa o nome de utilizador
    st.session_state["user_id"] = None # Limpa o ID do utilizador
    st.session_state["is_admin"] = False # Limpa o status de admin
    st.session_state["user_nome"] = None # Limpa o nome do utilizador
    st.session_state["user_email"] = None # Limpa o email do utilizador
    st.session_state["user_telefone"] = None # Limpa o telefone do utilizador
    st.success("Logout efetuado com sucesso!") # Mensagem de sucesso

def lista_utilizadores():
    """Lista todos os utilizadores da base de dados."""
    conn = get_db_connection() # Obtém a conexão com a base de dados
    if conn is None:
        return [] # Retorna uma lista vazia se a conexão falhar
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id, username, nome, email, telefone, is_admin FROM utilizadores")  # Consulta para listar utilizadores
        utilizadores = cursor.fetchall() # Obtém todos os utilizadores
        return utilizadores # Retorna a lista de utilizadores
    except mysql.connector.Error as err:
        st.error(f"Erro ao listar utilizadores: {err}") # Exibe erro caso falhe a consulta
        return [] # Retorna uma lista vazia em caso de erro
    finally:
        cursor.close() # Fecha o cursor
        conn.close() # Fecha a conexão com a base de dados

def eliminar_utilizador(id_utilizador):
    """Elimina um utilizador da base de dados."""
    
     # Obtém a conexão com a base de dados
    conn = get_db_connection()
    if conn is None: 
        return # Retorna se a conexão falhar
    try:
        cursor = conn.cursor()
        
         # Executa a query para eliminar o utilizador pelo ID
        cursor.execute("DELETE FROM utilizadores WHERE id = %s", (id_utilizador,)) # Exclui o utilizador com o ID fornecido
        conn.commit() # Confirma a remoção do utilizador
        
        st.success("Utilizador eliminado com sucesso!") # Mensagem de sucesso
        
    except mysql.connector.Error as err:
        st.error(f"Erro ao eliminar utilizador: {err}") # Exibe erro em caso de falha na query
        
    finally:
        cursor.close() # Fecha o cursor para liberar recursos
        conn.close() # Fecha a conexão com a base de dados

def atualizar_utilizador(id_utilizador, nome, email, telefone):
    """Atualiza o nome, email e telefone de um utilizador na base de dados."""
    
    # Valida os dados antes de atualizar
    if not validar_email(email) or not validar_telefone(telefone) or not valida_nome(nome):
        return False  # Retorna falso se os dados forem inválidos

    # Obtém a conexão com a base de dados
    conn = get_db_connection()
    if conn is None:
        return False # Retorna falso se a conexão falhar

    try:
        cursor = conn.cursor()
        
        # Verifica se o email já existe para outro utilizador   
        cursor.execute("SELECT * FROM utilizadores WHERE email = %s and id != %s", (email, id_utilizador))
        if cursor.fetchone(): # Se encontrar um utilizador com o mesmo email
            st.error("Este email do utilizador já existe!")
            return False
        
        # Verifica se o telefone já existe para outro utilizador
        cursor.execute("SELECT * FROM utilizadores WHERE telefone = %s and id != %s", (telefone, id_utilizador))
        if cursor.fetchone(): # Se encontrar um utilizador com o mesmo telefone
            st.error("Este número de telefone já existe!")
            return False
        
        # Atualiza os dados do utilizador na base de dados
        cursor.execute(
            "UPDATE utilizadores SET nome = %s, email = %s, telefone = %s WHERE id = %s",
            (nome, email, telefone, id_utilizador)
        )
        conn.commit() # Confirma as alterações na base de dados
        return True # Indica que a atualização foi bem-sucedida
    
    except mysql.connector.Error as err:
        st.error(f"Erro ao atualizar utilizador: {err}") # Exibe erro em caso de falha na query
        return False
    finally:
        cursor.close() # Fecha o cursor para liberar recursos
        conn.close() # Fecha a conexão com a base de dados
