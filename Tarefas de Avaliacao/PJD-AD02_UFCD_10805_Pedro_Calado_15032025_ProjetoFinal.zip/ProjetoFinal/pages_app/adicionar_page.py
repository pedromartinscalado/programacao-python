import streamlit as st
import re
import os
from utils.file_utils import sanitize_filename # Função para sanitizar o nome do arquivo da imagem
from utils.config import NO_IMAGE_PATH # Caminho para imagem padrão caso não seja carregada uma imagem
from database import product_db_functions # Funções de interação com a base de dados para produtos

def adicionar_page():
    st.subheader("Adicionar um Novo Produto") # Cabeçalho para a página de adicionar produto
    MAX_NOME_LENGTH = 100 # Comprimento máximo permitido para o nome do produto
    MAX_DESCRICAO_LENGTH = 500 # Comprimento máximo permitido para a descrição do produto
    MAX_IMAGE_SIZE_BYTES = 2 * 1024 * 1024 # Tamanho máximo permitido para a imagem (2MB)

    with st.form(key='produto_form_adicionar'): # Criação do formulário de entrada para o produto
        nome = st.text_input('Nome do Produto') # Campo de entrada para o nome do produto
        descricao = st.text_area('Descrição do Produto') # Campo de entrada para a descrição do produto
        preco = st.number_input('Preço', min_value=0.01, step=0.01)  # Campo de entrada para o preço do produto (mínimo 0.01)
        imagem_file = st.file_uploader("Carregar Imagem do Produto", type=["jpg", "jpeg", "png"]) # Campo de upload de imagem
        submit_button = st.form_submit_button(label='Inserir o Produto') # Botão de envio do formulário

        # Validação usando regex que permite caracteres acentuados e espaços
        pattern = r'^[\wÀ-ÿ\s]+$'  # Regex para validar caracteres alfanuméricos com acentos e espaços
        if submit_button: # Quando o botão de envio é pressionado
            if not nome.strip(): # Verifica se o nome não está vazio
                st.error('Por favor, insira um nome válido para o produto.')
            elif len(nome) > MAX_NOME_LENGTH: # Verifica se o nome não ultrapassa o limite de caracteres
                st.error(f'O nome do produto não pode ter mais de {MAX_NOME_LENGTH} caracteres.')
            elif nome.isdigit(): # Verifica se o nome não é composto apenas por números
                st.error('O nome do produto não pode conter apenas números.')
            elif not re.match(pattern, nome): # Verifica se o nome contém caracteres inválidos
                st.error('O nome do produto contém caracteres inválidos.')
            elif descricao.strip() == "": # Verifica se a descrição não está vazia
                st.error('A descrição não pode estar vazia.')
            elif len(descricao) > MAX_DESCRICAO_LENGTH: # Verifica se a descrição não ultrapassa o limite de caracteres
                st.error(f'A descrição do produto não pode ter mais de {MAX_DESCRICAO_LENGTH} caracteres.')
            elif not re.match(pattern, descricao): # Verifica se a descrição contém caracteres inválidos
                st.error('A descrição contém caracteres inválidos.')
            elif preco <= 0: # Verifica se o preço é maior que zero
                st.error('O preço deve ser maior que zero.')
            else:
                # Processamento e sanitização da imagem
                if imagem_file is not None: # Verifica se uma imagem foi carregada
                    if imagem_file.size > MAX_IMAGE_SIZE_BYTES: # Verifica se a imagem não excede o tamanho máximo
                        st.error(f"A imagem é demasiado grande. O tamanho máximo permitido é {MAX_IMAGE_SIZE_BYTES/(1024*1024):.2f} MB.")
                        imagem_path = None # Se a imagem for muito grande, não processa
                    else:
                        imagem_nome = sanitize_filename(imagem_file.name) # Sanitiza o nome do arquivo da imagem
                        imagem_path = os.path.join("images", imagem_nome) # Define o caminho para salvar a imagem
                        with open(imagem_path, "wb") as f: # Abre o arquivo em modo binário para escrita
                            f.write(imagem_file.getbuffer()) # Escreve o conteúdo da imagem no arquivo
                else:
                    imagem_path = NO_IMAGE_PATH # Caso não tenha imagem, usa a imagem padrão
                if imagem_path: # Só adiciona o produto à base de dados se a imagem for processada corretamente
                    product_db_functions.adiciona_produto(nome, descricao, preco, imagem_path) # Chama a função para adicionar o produto à base de dados                                                                                                      