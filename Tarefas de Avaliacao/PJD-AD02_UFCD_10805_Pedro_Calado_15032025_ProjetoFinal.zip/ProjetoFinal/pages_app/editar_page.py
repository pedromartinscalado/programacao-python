import streamlit as st
import re
import os
from utils.file_utils import sanitize_filename 
from database import product_db_functions  # Funções de interação com a base de dados para produtos

def editar_page():
    st.subheader("Editar Produto") # Cabeçalho para a página de editar produto
    MAX_NOME_LENGTH = 100   # Comprimento máximo permitido para o nome do produto
    MAX_DESCRICAO_LENGTH = 500  # Comprimento máximo permitido para a descrição do produto
    MAX_IMAGE_SIZE_BYTES = 2 * 1024 * 1024 # Tamanho máximo permitido para a imagem (2MB)

    produtos = product_db_functions.lista_produtos() # Obtém a lista de produtos da base de dados
    if not produtos: # Verifica se existem produtos para editar
        st.info("Não há produtos para editar.") # Exibe mensagem se não houver produtos
        return
    produto_selecionado = st.selectbox(
        "Escolha o Produto a Editar", # Cria um dropdown para selecionar o produto
        [f"{p['id']} - {p['nome']}" for p in produtos] # Exibe o id e nome de cada produto
    )
    if produto_selecionado:
         # Obtém o ID do produto selecionado e localiza o produto na lista
        id_produto_selecionado = int(produto_selecionado.split(" - ")[0])
        produto = next(p for p in produtos if p['id'] == id_produto_selecionado)
        # Formulário para editar as informações do produto
        with st.form(key=f'editar_form_{id_produto_selecionado}'):
            nome = st.text_input('Nome do Produto', produto['nome']) # Campo para editar o nome do produto
            descricao = st.text_area('Descrição do Produto', produto['descricao']) # Campo para editar a descrição
            preco = st.number_input('Preço', min_value=0.01, step=0.01, value=float(produto['preco'])) # Campo para editar o preço
            imagem_file = st.file_uploader("Carregar Nova Imagem do Produto", type=["jpg", "jpeg", "png"]) # Campo para carregar nova imagem
            submit_button = st.form_submit_button(label='Atualizar Produto') # Botão de envio do formulário
            pattern = r'^[\wÀ-ÿ\s]+$' # Regex para validar caracteres alfanuméricos com acentos e espaços
            if submit_button: # Quando o botão de envio é pressionado
                # Validação dos campos
                if not nome.strip():
                    st.error('Por favor, insira um nome válido para o produto.')
                elif len(nome) > MAX_NOME_LENGTH:
                    st.error(f'O nome do produto não pode ter mais de {MAX_NOME_LENGTH} caracteres.')
                elif nome.isdigit():
                    st.error('O nome do produto não pode conter apenas números.')
                elif not re.match(pattern, nome): # Verifica se o nome contém caracteres inválidos
                    st.error('O nome contém caracteres inválidos.')
                elif descricao.strip() == "":
                    st.error('A descrição não pode estar vazia.')
                elif len(descricao) > MAX_DESCRICAO_LENGTH:  # Verifica se a descrição não ultrapassa o limite de caracteres
                    st.error(f'A descrição do produto não pode ter mais de {MAX_DESCRICAO_LENGTH} caracteres.')
                elif not re.match(pattern, descricao): # Verifica se a descrição contém caracteres inválidos
                    st.error('A descrição contém caracteres inválidos.')
                elif preco <= 0: # Verifica se o preço é maior que zero
                    st.error('O preço deve ser maior que zero.')
                else:
                    # Processamento e validação da imagem
                    if imagem_file is not None:  # Verifica se uma nova imagem foi carregada
                        if imagem_file.size > MAX_IMAGE_SIZE_BYTES: # Verifica se a imagem não excede o tamanho máximo
                            st.error(f"A imagem é demasiado grande. O tamanho máximo permitido é {MAX_IMAGE_SIZE_BYTES/(1024*1024):.2f} MB.")
                            imagem_path = None # Não tenta processar uma imagem inválida
                        else:
                            # Sanitiza o nome do arquivo da imagem e define o caminho onde a imagem será armazenada
                            imagem_nome = sanitize_filename(imagem_file.name)
                            imagem_path = os.path.join("images", imagem_nome)
                            with open(imagem_path, "wb") as f:  # Abre o arquivo em modo binário para escrita
                                f.write(imagem_file.getbuffer()) # Escreve o conteúdo da imagem no arquivo
                    else:
                        imagem_path = produto['imagem'] # Caso não tenha nova imagem, mantém a imagem antiga
                    # Só atualiza o produto na base de dados se não houve erro na imagem ou se a imagem foi validada corretamente
                    if imagem_path:
                      # Atualiza as informações do produto na base de dados
                      product_db_functions.atualizar_produto(id_produto_selecionado, nome, descricao, preco, imagem_path)