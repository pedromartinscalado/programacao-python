from database import product_db_functions # Funções de interação com a base de dados para produtos
import streamlit as st # Biblioteca Streamlit para criação da interface

def eliminar_page():
    st.subheader("Eliminar Produto")  # Cabeçalho para a página de eliminar produto
    produtos = product_db_functions.lista_produtos() # Obtém a lista de produtos da base de dados
    if not produtos: # Verifica se existem produtos para eliminar
        st.info("Não há produtos para eliminar.")  # Exibe mensagem de informação, caso não haja produtos
        return
    # Cria um dropdown para o utilizador escolher o produto a eliminar, exibindo o id e nome
    produto_selecionado = st.selectbox(
        "Escolha o Produto a Eliminar",
        [f"{p['id']} - {p['nome']}" for p in produtos]
    )
    if produto_selecionado:
        # Obtém o ID do produto selecionado e localiza o produto na lista
        id_produto_selecionado = int(produto_selecionado.split(" - ")[0])
        produto = next(p for p in produtos if p['id'] == id_produto_selecionado)
        
        # Pergunta ao utilizador se tem a certeza de que quer eliminar o produto
        confirm = st.checkbox(f"Tem a certeza que deseja excluir o produto {produto['nome']}?")
        # Se o utilizador marcar a caixa de verificação e clicar no botão, o produto será eliminado
        if confirm and st.button(f"Eliminar {produto['nome']}"):
          product_db_functions.eliminar_produto(id_produto_selecionado) # Chama a função para eliminar o produto da base de dados