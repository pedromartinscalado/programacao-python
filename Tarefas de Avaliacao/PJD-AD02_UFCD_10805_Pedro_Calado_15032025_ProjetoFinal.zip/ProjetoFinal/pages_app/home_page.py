import streamlit as st # Biblioteca Streamlit para criação da interface
import os # Módulo para interagir com o sistema de arquivos
from database.product_db_functions import lista_produtos  # Função para listar os produtos da base de dados
from utils.config import NO_IMAGE_PATH # Caminho para uma imagem padrão caso a imagem do produto não exista  

def get_product_image(image_path):
    """Função para obter o caminho correto da imagem do produto."""
    if image_path and os.path.exists(image_path):  # Verifica se o caminho da imagem existe
        return image_path # Retorna o caminho da imagem se for válido
    return NO_IMAGE_PATH # Caso contrário, retorna o caminho de imagem padrão (sem imagem)

def home_page():
    st.subheader("Bem-vindo à Loja de Moda!") # Cabeçalho da página inicial
    st.write("Esta é uma plataforma para gerir os produtos da loja.")  # Descrição da plataforma
    st.write("Use o menu lateral para navegar nas diferentes secções.") # Orientação para o utilizador

    # Destaque para alguns produtos na página inicial
    st.subheader("Produtos em Destaque")
    
    try:
        produtos = lista_produtos()  # Tenta listar os produtos da base de dados
    except Exception as e:
        st.error(f"Ocorreu um erro ao carregar os produtos: {e}") # Exibe mensagem de erro caso falhe a listagem dos produtos
        return

    if not produtos: # Verifica se não há produtos disponíveis
        st.info("Não há produtos disponíveis no momento. Tente novamente mais tarde.") # Exibe mensagem caso não existam produtos
        return

    # Mostrar apenas até 3 produtos em destaque
    produtos_destaque = produtos[:min(3, len(produtos))] # Limita a exibição aos primeiros 3 produtos ou ao total de produtos disponíveis
    cols = st.columns(len(produtos_destaque)) # Cria colunas para cada produto em destaque

    for i, produto in enumerate(produtos_destaque): # Itera sobre os produtos em destaque
        with cols[i]: # Para cada coluna, exibe um produto
            imagem_produto = get_product_image(produto['imagem'])  # Obter a imagem do produto usando a função get_product_image
            if imagem_produto == NO_IMAGE_PATH: # Se a imagem não estiver disponível
                st.warning(f"Imagem não disponível para o produto: {produto['nome']}") # Aviso de que a imagem não está disponível
            st.image(imagem_produto, use_container_width=True) # Exibe a imagem do produto (ou a imagem padrão)
            st.write(f"**{produto['nome']}**") # Exibe o nome do produto em negrito
            st.write(f"Preço: €{produto['preco']:.2f}") # Exibe o preço do produto com 2 casas decimais
            st.write(produto['descricao']) # Exibe a descrição do produto
