import streamlit as st # Biblioteca Streamlit para criação da interface
import os # Módulo para interagir com o sistema de arquivos
from database.database import lista_produtos # Função para listar os produtos da base de dados
from utils.config import NO_IMAGE_PATH # Caminho para uma imagem padrão caso a imagem do produto não exista
from area_utilizador.area_utilizador import adicionar_wishlist  # Função para adicionar produtos à wishlist

def produtos_page():
    st.subheader("Produtos Disponíveis") # Cabeçalho da página de produtos disponíveis
    produtos = lista_produtos() # Obtém a lista de produtos da base de dados
    
    # Filtrar produtos com base na pesquisa do utilizador
    if "search" not in st.session_state: # Verifica se não há pesquisa armazenada no estado da sessão
        st.session_state["search"] = "" # Inicializa a pesquisa como uma string vazia  
        filtro = st.session_state["search"].lower() # Filtro de pesquisa em minúsculas para comparação
        produtos = [p for p in produtos if filtro in p["nome"].lower() or filtro in p["descricao"].lower()]  # Filtra produtos pelo nome ou descrição
    if produtos: # Verifica se há produtos após o filtro
        cols_per_row = 3 # Número de colunas a serem exibidas por linha
        for i in range(0, len(produtos), cols_per_row): # Divide os produtos em grupos de 3
            cols = st.columns(cols_per_row) # Cria as colunas na interface
            for col, produto in zip(cols, produtos[i:i+cols_per_row]): # Para cada coluna, exibe um produto
                with col:
                    # Exibe a imagem do produto ou uma imagem padrão se não houver imagem disponível
                    st.image(produto['imagem'] if produto['imagem'] and os.path.exists(produto['imagem'])
                             else NO_IMAGE_PATH,
                             use_container_width=True)
                    st.write(f"**{produto['nome']}**") # Exibe o nome do produto em negrito
                    st.write(f"Preço: €{produto['preco']:.2f}") # Exibe o preço do produto com 2 casas decimais
                    
                    # Verifica se o utilizador está autenticado para permitir adicionar à wishlist
                    if st.session_state['logged_in'] == True:
                        # Botão para adicionar o produto à wishlist
                        if st.button(f"Adicionar à Wishlist", key=f"wishlist_{produto['id']}"):
                            adicionar_wishlist(produto['id']) # Chama a função para adicionar o produto à wishlist
    else:
        st.info("Não foram encontrados produtos ou a base de dados está vazia.") # Mensagem caso não haja produtos após o filtro