import streamlit as st # Biblioteca Streamlit para criação da interface
import os # Módulo para interagir com o sistema de arquivos
from utils.config import NO_IMAGE_PATH  # Caminho para uma imagem padrão caso a imagem do produto não exista
from database.product_db_functions import lista_produtos # Função para listar os produtos da base de dados

def wishlist_page():
    st.subheader("A sua Wishlist") # Cabeçalho da página da wishlist

    # Verifica se a wishlist existe no estado da sessão. Caso contrário, cria uma lista vazia
    if "wishlist" not in st.session_state:
        st.session_state["wishlist"] = [] # Inicializa a wishlist como uma lista vazia

    # Verifica se a wishlist está vazia
    if not st.session_state["wishlist"]: 
        st.info("Não há produtos na Wishlist.") # Mensagem caso não haja produtos na wishlist
        return
    produtos = lista_produtos() # Obtém a lista de produtos da base de dados
    # Filtra os produtos que estão na wishlist com base no ID
    produtos_wishlist = [p for p in produtos if p['id'] in st.session_state["wishlist"]]
    
    if produtos_wishlist: # Se houver produtos na wishlist
        cols_per_row = 3 # Define o número de colunas a serem exibidas por linha
        for i in range(0, len(produtos_wishlist), cols_per_row): # Divide os produtos em grupos de 3
            cols = st.columns(cols_per_row) # Cria as colunas na interface
            for col, produto in zip(cols, produtos_wishlist[i:i+cols_per_row]):  # Para cada coluna, exibe um produto
                with col:
                    # Exibe a imagem do produto ou uma imagem padrão caso não haja imagem disponível
                    st.image(produto['imagem'] if produto['imagem'] and os.path.exists(produto['imagem'])
                             else NO_IMAGE_PATH,
                             use_container_width=True)
                    st.write(f"**{produto['nome']}**") # Exibe o nome do produto em negrito
                    st.write(f"Preço: €{produto['preco']:.2f}")  # Exibe o preço do produto com 2 casas decimais
                    
                    # Botão para remover o produto da wishlist
                    if st.button(f"Remover", key=f"remove_wishlist_{produto['id']}"):
                        st.session_state["wishlist"].remove(produto['id']) # Remove o produto da wishlist
    else:
        st.info("A Wishlist está vazia.") # Mensagem caso não haja produtos na wishlist