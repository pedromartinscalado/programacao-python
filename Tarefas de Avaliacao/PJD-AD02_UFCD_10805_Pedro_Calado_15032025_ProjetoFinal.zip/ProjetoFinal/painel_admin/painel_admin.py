import streamlit as st
from utils.file_utils import sanitize_filename
from database.product_db_functions import lista_produtos
from pages_app.adicionar_page import adicionar_page
from pages_app.editar_page import editar_page
from pages_app.eliminar_page import eliminar_page

# Função principal para exibir o painel de administração
def painel_admin_page():
    st.title("Painel de Administração")
    st.write("Bem-vindo ao painel de administração da loja!")
    st.write("Aqui você pode gerenciar os produtos e outras configurações da loja.")

    # Obtém a página atual do painel admin a partir da sessão
    current_page = st.session_state.get("admin_subpage", "Painel Principal")

    if current_page == "Painel Principal":
        st.subheader("Visão Geral dos Produtos")
        
        products = lista_produtos()  # Obtém a lista de produtos da base de dados
        total_products = len(products)
        st.metric("Total de Produtos", total_products)  # Exibe a métrica do total dos produtos

        if products:
            st.subheader("Produtos Recentes")
            st.table(products[:5])  # Mostra os 5 primeiros produtos da lista

        st.subheader("Ações Rápidas")
        col1, col2, col3 = st.columns(3)
        
        # Botão para adicionar um novo produto
        with col1:
            if st.button("Adicionar Novo Produto"):
                st.session_state["admin_subpage"] = "Adicionar Produto"
                st.rerun()
        # Botão para editar um produto existente
        with col2:
            if st.button("Editar Produto"):
                st.session_state["admin_subpage"] = "Editar Produto"
                st.rerun()
        # Botão para eliminar um produto
        with col3:
            if st.button("Eliminar Produto"):
                st.session_state["admin_subpage"] = "Eliminar Produto"
                st.rerun()

    # Redireciona para a página correspondente de acordo com a ação selecionada
    elif current_page == "Adicionar Produto":
        adicionar_page()
    elif current_page == "Editar Produto":
        editar_page()
    elif current_page == "Eliminar Produto":
        eliminar_page()

    # Botão para voltar ao painel principal
    if current_page != "Painel Principal":
        if st.button("Voltar ao Painel Admin"):
            st.session_state["admin_subpage"] = "Painel Principal"
            st.rerun()

# Exemplo de sanitização de nome de ficheiro
nome_ficheiro_original = "Nome do Ficheiro Com Caracteres #$%^&*.txt"
nome_ficheiro_seguro = sanitize_filename(nome_ficheiro_original)
print(f"Nome de ficheiro original: {nome_ficheiro_original}")
print(f"Nome de ficheiro sanitizado: {nome_ficheiro_seguro}")