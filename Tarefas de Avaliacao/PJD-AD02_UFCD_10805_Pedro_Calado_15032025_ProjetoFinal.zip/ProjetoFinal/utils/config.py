import os

# Caminho da imagem padrão (usada quando não há uma imagem disponível para um produto ou utilizador)
NO_IMAGE_PATH = "images/noimage.jpg"

# Verifica se o diretório 'images' existe; caso contrário, cria-o para garantir que as imagens podem ser armazenadas corretamente
if not os.path.exists("images"):
    os.makedirs("images")

# Configuração da ligação ao MySQL
# Estes parâmetros são usados para estabelecer a conexão com o banco de dados da aplicação
db_config = {
    'host': 'localhost', # Servidor do banco de dados (localhost para ambiente local)
    'user': 'root',      # Nome de utilizador do MySQL
    'password': '',      # Senha do utilizador do MySQL (vazia por padrão, mas pode ser alterada para segurança)
    'database': 'loja_modas' # Nome da base de dados utilizada pela aplicação
}