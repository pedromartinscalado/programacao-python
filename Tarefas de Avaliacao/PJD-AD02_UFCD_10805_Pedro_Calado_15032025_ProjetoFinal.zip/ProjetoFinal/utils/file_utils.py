import re

# Função para sanitizar o nome do ficheiro, substituindo caracteres indesejados
# Remove qualquer caractere que não seja uma letra, número, sublinhado, ponto ou hífen
# Isso evita problemas ao guardar ou aceder ficheiros com nomes inválidos

def sanitize_filename(filename):
    return re.sub(r'[^\w\.-]', '_', filename)  # Substitui caracteres inválidos por "_"