import streamlit as st

# Função para inicializar variáveis de sessão na aplicação Streamlit
# As variáveis de sessão são usadas para armazenar informações do utilizador e estado da aplicação

def init_session_state():
    """Inicializa variáveis de sessão para gerir estado do utilizador e da aplicação."""
    
    # Estado de login do utilizador (False por padrão, até o utilizador autenticar-se)
    if "logged_in" not in st.session_state:
        st.session_state["logged_in"] = False
    # Nome de utilizador autenticado (string vazia por padrão)   
    if "username" not in st.session_state:
        st.session_state["username"] = ""
    # ID do utilizador autenticado (None por padrão)
    if "user_id" not in st.session_state:
        st.session_state["user_id"] = None
    # Estado de administrador (False por padrão, apenas True para utilizadores admin)
    if "is_admin" not in st.session_state:
        st.session_state["is_admin"] = False
    # Lista de favoritos (wishlist) do utilizador, vazia por padrão
    if "wishlist" not in st.session_state:
        st.session_state["wishlist"] = []
    # Termo de pesquisa atual inserido pelo utilizador
    if "search" not in st.session_state:
        st.session_state["search"] = ""
    # Página atual da aplicação (começa na página inicial "Home")
    if "current_page" not in st.session_state:
        st.session_state["current_page"] = "Home"
    # Estado para controlar se o botão de wishlist foi clicado
    if "wishlist_clicked" not in st.session_state:
        st.session_state["wishlist_clicked"] = False
    # Nome do utilizador autenticado (None por padrão, definido após login)
    if "user_nome" not in st.session_state: 
        st.session_state["user_nome"] = None
    # Email do utilizador autenticado (None por padrão, definido após login)
    if "user_email" not in st.session_state: 
        st.session_state["user_email"] = None
